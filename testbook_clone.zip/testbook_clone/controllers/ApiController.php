<?php

class ApiController extends Controller {

    public function __construct() {
        if (!isset($_SESSION['user_id'])) {
            $this->jsonResponse(['error' => 'Unauthorized'], 401);
        }
        
        if (!class_exists('TestSessionModel')) require_once '../models/TestSessionModel.php';
        if (!class_exists('QuizModel')) require_once '../models/QuizModel.php';

        // Parse JSON input automatically for APIs
        $this->postData = json_decode(file_get_contents('php://input'), true);
    }

    private function jsonResponse($data, $status = 200) {
        header('Content-Type: application/json');
        http_response_code($status);
        echo json_encode($data);
        exit;
    }

    /**
     * Fetch questions and previously saved state for the active test
     */
    public function fetch_questions() {
        if (!isset($_SESSION['active_test_session_id'])) {
            $this->jsonResponse(['error' => 'No active session'], 400);
        }

        $sessionId = $_SESSION['active_test_session_id'];
        $quizId = $_GET['quiz_id'] ?? 0;
        $langId = $_GET['lang_id'] ?? 1;

        $quizModel = new QuizModel();
        $questions = $quizModel->getQuizQuestions($quizId, $langId);

        $sessionModel = new TestSessionModel();
        $responses = $sessionModel->getSessionResponses($sessionId);

        // Map responses back to questions
        $responsesMap = [];
        foreach ($responses as $r) {
            $responsesMap[$r['question_id']] = [
                'selected_option_id' => $r['selected_option_id'],
                'status' => $r['status']
            ];
        }

        foreach ($questions as &$q) {
            $prev = $responsesMap[$q['id']] ?? null;
            if ($prev) {
                $q['selected_option_id'] = $prev['selected_option_id'];
                $q['status'] = $prev['status'];
            } else {
                $q['selected_option_id'] = null;
                $q['status'] = 'not_visited';
            }
        }

        $this->jsonResponse(['status' => 'success', 'questions' => $questions]);
    }

    /**
     * Ping API to save individual answer asynchronously and sync timer
     */
    public function save_answer() {
        if (!isset($_SESSION['active_test_session_id'])) {
            $this->jsonResponse(['error' => 'No active session'], 400);
        }

        $sessionId = $_SESSION['active_test_session_id'];
        $questionId = $this->postData['question_id'] ?? null;
        $selectedOptionId = $this->postData['selected_option_id'] ?? null;
        $status = $this->postData['status'] ?? 'not_answered';
        $timeSpent = $this->postData['time_spent_seconds'] ?? 0;
        $timeRemaining = $this->postData['time_remaining_seconds'] ?? null;

        if (!$questionId) {
            $this->jsonResponse(['error' => 'Missing question_id'], 400);
        }

        $sessionModel = new TestSessionModel();
        
        // Save answer state
        $saved = $sessionModel->saveAnswer($sessionId, $questionId, $selectedOptionId, $status, $timeSpent);

        // Sync timer
        if ($timeRemaining !== null) {
            $sessionModel->pingSessionTime($sessionId, $timeRemaining);
        }

        if ($saved) {
            $this->jsonResponse(['status' => 'success']);
        } else {
            $this->jsonResponse(['error' => 'Failed to save'], 500);
        }
    }

    /**
     * Submit the test manually or upon timeout
     */
    public function submit_test() {
        if (!isset($_SESSION['active_test_session_id'])) {
            $this->jsonResponse(['error' => 'No active session'], 400);
        }

        $sessionId = $_SESSION['active_test_session_id'];
        $sessionModel = new TestSessionModel();
        $sessionModel->submitTest($sessionId);

        unset($_SESSION['active_test_session_id']);

        $this->jsonResponse(['status' => 'success', 'message' => 'Test submitted effortlessly.']);
    }
}
