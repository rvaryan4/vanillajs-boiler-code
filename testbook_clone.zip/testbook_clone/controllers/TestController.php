<?php

class TestController extends Controller {

    public function __construct() {
        if (!class_exists('QuizModel')) require_once '../models/QuizModel.php';
        if (!class_exists('SeoModel')) require_once '../models/SeoModel.php';
        if (!class_exists('LanguageModel')) require_once '../models/LanguageModel.php';
    }

    public function index($slug = '') {
        if (empty($slug)) {
            header("Location: " . APP_URL);
            exit;
        }

        $langModel = new LanguageModel();
        $langCode = defined('APP_LANG') ? APP_LANG : 'en';
        $langId = $langModel->getLanguageIdByCode($langCode);

        $quizModel = new QuizModel();
        $quiz = $quizModel->getQuiz($slug); // QuizModel natively handles slug or ID

        if (!$quiz) {
            die("Test not found.");
        }

        // Fetch translations for SEO explicitly
        $stmt = Database::getInstance()->getConnection()->prepare("
            SELECT COALESCE(qt.title, qt_en.title) as title,
                   COALESCE(qt.description, qt_en.description) as description,
                   COALESCE(qt.meta_title, qt_en.meta_title, qt.title) as meta_title,
                   COALESCE(qt.meta_description, qt_en.meta_description, qt.description) as meta_description
            FROM quizzes q
            LEFT JOIN quiz_translations qt ON q.id = qt.quiz_id AND qt.language_id = ?
            LEFT JOIN quiz_translations qt_en ON q.id = qt_en.quiz_id AND qt_en.language_id = (SELECT id FROM languages WHERE code = 'en')
            WHERE q.id = ?
        ");
        $stmt->execute([$langId, $quiz['id']]);
        $seoData = $stmt->fetch(PDO::FETCH_ASSOC);

        $seoModel = new SeoModel();
        $breadcrumbs = $seoModel->getCategoryBreadcrumbs($quiz['category_id'], $langId);
        // Append current test to breadcrumbs
        $breadcrumbs[] = [
            'url' => APP_URL . '/' . $langCode . '/test/' . $quiz['slug'],
            'name' => $seoData['title']
        ];

        $data = [
            'quiz' => array_merge($quiz, $seoData),
            'meta_title' => $seoData['meta_title'] . " Test Series | " . APP_NAME,
            'meta_description' => $seoData['meta_description'],
            'canonical_url' => APP_URL . '/' . $langCode . '/test/' . $quiz['slug'],
            'breadcrumbs' => $breadcrumbs
        ];

        $this->view('seo/test', $data);
    }
}
