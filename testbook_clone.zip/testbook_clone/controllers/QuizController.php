<?php

class QuizController extends Controller {

    public function __construct() {
        if (!isset($_SESSION['user_id'])) {
            header('Location: ' . APP_URL . '/auth/login');
            exit;
        }
        
        if (!class_exists('QuizModel')) {
            require_once '../models/QuizModel.php';
        }
        if (!class_exists('LanguageModel')) {
            require_once '../models/LanguageModel.php';
        }
        if (!class_exists('TestSessionModel')) {
            require_once '../models/TestSessionModel.php';
        }
    }

    /**
     * Screen 1: General Instructions
     */
    public function instructions($quizId) {
        require_once '../core/helpers.php';
        requirePremiumAccess($quizId);

        $quizModel = new QuizModel();
        $quiz = $quizModel->getQuiz($quizId);

        if (!$quiz) die("Quiz not found.");

        $data = ['quiz' => $quiz];
        $this->view('quiz/instructions', $data);
    }

    /**
     * Screen 2: Test Configuration (Language Selection & Declaration)
     */
    public function config($quizId) {
        require_once '../core/helpers.php';
        requirePremiumAccess($quizId);

        $quizModel = new QuizModel();
        $quiz = $quizModel->getQuiz($quizId);
        
        if (!$quiz) die("Quiz not found.");

        $langModel = new LanguageModel();
        $languages = $langModel->getActiveLanguages();

        $data = [
            'quiz' => $quiz,
            'languages' => $languages
        ];
        $this->view('quiz/config', $data);
    }

    /**
     * Screen 3: The actual quiz interface
     * Initialized after user accepts the declaration in Screen 2
     */
    public function interface($quizId) {
        require_once '../core/helpers.php';
        requirePremiumAccess($quizId);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Started or resumed from config screen
            $selectedLangCode = $_POST['language'] ?? 'en';
            $_SESSION['quiz_lang'] = $selectedLangCode;
        }

        $quizModel = new QuizModel();
        $quiz = $quizModel->getQuiz($quizId);
        if (!$quiz) die("Quiz not found.");

        $langModel = new LanguageModel();
        $langCode = $_SESSION['quiz_lang'] ?? 'en';
        $langId = $langModel->getLanguageIdByCode($langCode);

        $sessionModel = new TestSessionModel();
        
        // Start or Resume the session
        // Assuming time_limit_minutes is in the DB
        $timeLimitSeconds = $quiz['time_limit_minutes'] * 60;
        $sessionInfo = $sessionModel->startOrResumeSession($_SESSION['user_id'], $quiz['id'], $langId, $timeLimitSeconds);

        if ($sessionInfo === false) {
            // Already submitted or time expired
            die("This test has already been submitted. Showing results is unimplemented in this phase.");
        }

        $_SESSION['active_test_session_id'] = $sessionInfo['id'];

        $data = [
            'quiz' => $quiz,
            'session' => $sessionInfo,
            'lang_id' => $langId
        ];

        // This view will be mostly empty HTML structure loaded with Javascript later
        $this->view('quiz/interface', $data);
    }
}
