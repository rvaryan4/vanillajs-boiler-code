<?php

class AdminTranslationController extends Controller {

    public function __construct() {
        // Ensure user is admin (simplified for brevity)
        // require_once '../core/Auth.php';
        // if (!Auth::isAdmin()) { header('Location: /login'); exit; }
        
        // Ensure model is loaded
        if (!class_exists('LanguageModel')) {
            require_once '../models/LanguageModel.php';
        }
    }

    public function index() {
        $langModel = new LanguageModel();
        $data = [
            'languages' => $langModel->getActiveLanguages()
        ];
        $this->view('admin/translations', $data);
    }

    public function add() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $table = $_POST['table'] ?? '';
            $entity_col = $_POST['entity_col'] ?? '';
            $entity_id = $_POST['entity_id'] ?? '';
            $lang_id = $_POST['language_id'] ?? '';
            $field = $_POST['field'] ?? '';
            $text = $_POST['text'] ?? '';

            // Whitelist tables to prevent SQL injection
            $allowedTables = [
                'category_translations' => ['category_id', ['name', 'description', 'meta_title']],
                'quiz_translations' => ['quiz_id', ['title', 'description', 'instructions']],
                'question_translations' => ['question_id', ['question_text', 'explanation']],
                'question_option_translations' => ['option_id', ['option_text']]
            ];

            if (!isset($allowedTables[$table])) {
                die("Invalid table.");
            }
            if ($allowedTables[$table][0] !== $entity_col || !in_array($field, $allowedTables[$table][1])) {
                die("Invalid column or field for this table.");
            }

            if ($entity_id && $lang_id && $text) {
                // Example Query for adding/updating translation
                $db = (new LanguageModel()); // Just to get a DB instance from our abstraction, or we can use Database::getInstance()->getConnection()
                $conn = Database::getInstance()->getConnection();
                
                $sql = "INSERT INTO `{$table}` (`{$entity_col}`, `language_id`, `{$field}`) VALUES (?, ?, ?) 
                        ON DUPLICATE KEY UPDATE `{$field}` = ?";
                $stmt = $conn->prepare($sql);
                $stmt->execute([$entity_id, $lang_id, $text, $text]);

                header("Location: " . APP_URL . "/admintranslation?success=1");
                exit;
            } else {
                die("Missing fields");
            }
        }
    }
}
