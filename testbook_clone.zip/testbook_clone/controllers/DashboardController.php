<?php

class DashboardController extends Controller {

    public function __construct() {
        if (!isset($_SESSION['user_id'])) {
            header("Location: " . APP_URL . "/auth/login");
            exit;
        }

        if (!class_exists('AnalyticsModel')) {
            require_once '../models/AnalyticsModel.php';
        }
    }

    public function index() {
        $analyticsModel = new AnalyticsModel();
        $userId = $_SESSION['user_id'];

        $history = $analyticsModel->getUserTestHistory($userId);
        $overallStats = $analyticsModel->getOverallStats($userId);
        $weakTopics = $analyticsModel->getWeakTopics($userId);

        // Prepare chart points (Recent 10 tests, chronological)
        $chartLabels = [];
        $chartData = [];
        $recentHistory = array_slice(array_reverse($history), -10); // get oldest first out of latest 10
        foreach($recentHistory as $idx => $h) {
            $chartLabels[] = "T" . ($idx + 1) . " (" . date('d M', strtotime($h['start_time'])) . ")";
            $chartData[] = $h['accuracy'];
        }

        $data = [
            'meta_title' => 'My Dashboard - Performance Analytics | ' . APP_NAME,
            'history' => $history,
            'stats' => $overallStats,
            'weak_topics' => $weakTopics,
            'chart_labels' => json_encode($chartLabels),
            'chart_data' => json_encode($chartData),
            'subscription' => $_SESSION['subscription_status'] ?? 'free'
        ];

        $this->view('analytics/dashboard', $data);
    }
}
