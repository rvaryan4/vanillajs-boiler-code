<?php
class AuthController extends Controller {
    public function index() {
        $this->redirect('/auth/login');
    }

    public function login() {
        Auth::guest(); // Middleware check
        
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            Auth::verifyCSRF($_POST['csrf_token'] ?? '');
            
            $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
            $password = $_POST['password']; 
            
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $data['error'] = 'Invalid email format.';
                $data['csrf_token'] = Auth::generateCSRF();
                $this->view('auth/login', $data);
                return;
            }

            $userModel = $this->model('User');
            $user = $userModel->findByEmail($email);
            
            if ($user && password_verify($password, $user['password_hash'])) {
                // CSRF & Fixation Protection
                session_regenerate_id(true);

                $session_id = $userModel->createSession($user['id'], $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']);
                
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_role'] = $user['role'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['db_session_id'] = $session_id;
                
                // Store language preference from DB
                if (!empty($user['preferred_language_id'])) {
                    // Quick map for demo purposes (1=en, 2=hi)
                    $langMap = [1 => 'en', 2 => 'hi'];
                    $_SESSION['lang'] = $langMap[$user['preferred_language_id']] ?? DEFAULT_LANG;
                    $_SESSION['language_id'] = $user['preferred_language_id'];
                }
                
                // Redirect requirement fulfilled
                $this->redirect('/dashboard');
            } else {
                $data['error'] = 'Invalid email or password.';
                $data['csrf_token'] = Auth::generateCSRF();
                $this->view('auth/login', $data);
                return;
            }
        }
        
        $data['csrf_token'] = Auth::generateCSRF();
        $this->view('auth/login', $data);
    }

    public function register() {
        Auth::guest(); // Middleware check
        
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            Auth::verifyCSRF($_POST['csrf_token'] ?? '');
            
            // Required Sanitiation & Validation
            $name = trim(htmlspecialchars($_POST['name']));
            $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
            $password = $_POST['password'];
            $lang_id = $_POST['language_id'] ?? 1; // 1 = English
            
            $errors = [];
            if (empty($name) || strlen($name) < 3) $errors[] = "Name must be at least 3 characters.";
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Invalid email format.";
            if (strlen($password) < 8) $errors[] = "Password must be at least 8 characters.";
            
            if (!empty($errors)) {
                $data['error'] = implode("<br>", $errors);
                $data['csrf_token'] = Auth::generateCSRF();
                $this->view('auth/register', $data);
                return;
            }

            $userModel = $this->model('User');
            if ($userModel->findByEmail($email)) {
                $data['error'] = 'Email is already taken.';
                $data['csrf_token'] = Auth::generateCSRF();
                $this->view('auth/register', $data);
                return;
            }
            
            if ($userModel->register($name, $email, $password, $lang_id)) {
                $data['success'] = 'Registration successful. Please login.';
                $data['csrf_token'] = Auth::generateCSRF();
                $this->view('auth/login', $data);
                return;
            }
        }
        
        $data['csrf_token'] = Auth::generateCSRF();
        $this->view('auth/register', $data);
    }

    public function logout() {
        if (isset($_SESSION['db_session_id'])) {
            $userModel = $this->model('User');
            $userModel->destroySession($_SESSION['db_session_id']);
        }
        
        // Ensure fixation safety on logout
        session_unset();
        session_destroy();
        session_start();
        session_regenerate_id(true);

        $this->redirect('/auth/login');
    }
}
