<?php

class AdminController extends Controller {

    private $adminModel;

    public function __construct() {
        if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
            header("Location: " . APP_URL . "/auth/login");
            exit;
        }

        if(!class_exists('AdminModel')) {
            require_once '../models/AdminModel.php';
        }
        $this->adminModel = new AdminModel();
    }

    public function index() {
        $this->view('admin/dashboard');
    }

    // --- Users --- //
    public function users() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $userId = $_POST['user_id'] ?? 0;
            $status = $_POST['subscription_status'] ?? 'free';
            $this->adminModel->toggleUserSubscription($userId, $status);
            header("Location: " . APP_URL . "/admin/users?success=1");
            exit;
        }

        $data = ['users' => $this->adminModel->getUsers()];
        $this->view('admin/users', $data);
    }

    // --- Categories --- //
    public function categories() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $parentId = $_POST['parent_id'] ?? null;
            $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $_POST['slug'] ?? '')));
            $status = $_POST['status'] ?? 'active';
            $enName = $_POST['en_name'] ?? '';
            $enDesc = $_POST['en_desc'] ?? '';
            $hiName = $_POST['hi_name'] ?? '';
            $hiDesc = $_POST['hi_desc'] ?? '';
            
            if ($slug && $enName) {
                $this->adminModel->addCategory($parentId, $slug, $status, $enName, $enDesc, $hiName, $hiDesc);
                header("Location: " . APP_URL . "/admin/categories?success=1");
                exit;
            }
        }

        $data = ['categories' => $this->adminModel->getCategories()];
        $this->view('admin/categories', $data);
    }

    // --- Quizzes --- //
    public function quizzes() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $categoryId = $_POST['category_id'] ?? null;
            $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $_POST['slug'] ?? '')));
            $timeLimit = $_POST['time_limit_minutes'] ?? 60;
            $totalMarks = $_POST['total_marks'] ?? 100;
            $passingMarks = $_POST['passing_marks'] ?? 40;
            $isPremium = $_POST['is_premium'] ?? 0;
            $status = $_POST['status'] ?? 'draft';
            
            $enTitle = $_POST['en_title'] ?? '';
            $enDesc = $_POST['en_desc'] ?? '';
            $hiTitle = $_POST['hi_title'] ?? '';
            $hiDesc = $_POST['hi_desc'] ?? '';

            if ($categoryId && $slug && $enTitle) {
                $this->adminModel->addQuiz($categoryId, $slug, $timeLimit, $totalMarks, $passingMarks, $isPremium, $status, $enTitle, $enDesc, $hiTitle, $hiDesc);
                header("Location: " . APP_URL . "/admin/quizzes?success=1");
                exit;
            }
        }

        $data = [
            'quizzes' => $this->adminModel->getQuizzes(),
            'categories' => $this->adminModel->getCategories()
        ];
        $this->view('admin/quizzes', $data);
    }

    // --- Questions --- //
    public function questions($quizId = null) {
        if (!$quizId) die("Quiz ID required");

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $type = $_POST['type'] ?? 'multiple_choice';
            $marks = $_POST['marks'] ?? 1.0;
            $negMarks = $_POST['negative_marks'] ?? 0.0;
            $difficulty = $_POST['difficulty'] ?? 'medium';
            $enText = $_POST['en_question_text'] ?? '';
            $hiText = $_POST['hi_question_text'] ?? '';
            
            // Build options array
            $optionsData = [];
            for($i = 0; $i < 4; $i++) {
                if(isset($_POST['en_opt_'.$i])) {
                    $optionsData[] = [
                        'is_correct' => ($_POST['correct_option'] ?? 0) == $i ? 1 : 0,
                        'en_text' => $_POST['en_opt_'.$i],
                        'hi_text' => $_POST['hi_opt_'.$i] ?? ''
                    ];
                }
            }

            if ($enText && !empty($optionsData)) {
                $this->adminModel->addQuestion($quizId, $type, $marks, $negMarks, $difficulty, $enText, $hiText, $optionsData);
                header("Location: " . APP_URL . "/admin/questions/" . $quizId . "?success=1");
                exit;
            }
        }

        $data = [
            'quiz_id' => $quizId,
            'questions' => $this->adminModel->getQuestionsByQuiz($quizId)
        ];
        $this->view('admin/questions', $data);
    }
}
