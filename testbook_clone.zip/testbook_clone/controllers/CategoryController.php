<?php

class CategoryController extends Controller {

    public function __construct() {
        if (!class_exists('CategoryModel')) require_once '../models/CategoryModel.php';
        if (!class_exists('SeoModel')) require_once '../models/SeoModel.php';
        if (!class_exists('LanguageModel')) require_once '../models/LanguageModel.php';
    }

    public function index($slug = '') {
        if (empty($slug)) {
            // Can redirect to home or show list of categories
            header("Location: " . APP_URL);
            exit;
        }

        $langModel = new LanguageModel();
        $langCode = defined('APP_LANG') ? APP_LANG : 'en';
        $langId = $langModel->getLanguageIdByCode($langCode);

        $catModel = new CategoryModel();
        $category = $catModel->getCategoryBySlug($slug, $langId);

        if (!$category) {
            die("Category not found.");
        }

        $seoModel = new SeoModel();
        $breadcrumbs = $seoModel->getCategoryBreadcrumbs($category['id'], $langId);

        $quizzes = $catModel->getQuizzesByCategory($category['id'], $langId);

        $data = [
            'category' => $category,
            'quizzes' => $quizzes,
            'meta_title' => $category['meta_title'] . " | " . APP_NAME,
            'meta_description' => $category['meta_description'],
            'canonical_url' => APP_URL . '/' . $langCode . '/category/' . $category['slug'],
            'breadcrumbs' => $breadcrumbs
        ];

        $this->view('seo/category', $data);
    }
}
