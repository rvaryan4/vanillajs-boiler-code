<?php

class SubscriptionController extends Controller {

    public function __construct() {
        if (!isset($_SESSION['user_id'])) {
            header("Location: " . APP_URL . "/auth/login?redirect=subscription/plans");
            exit;
        }
        if (!class_exists('SubscriptionModel')) {
            require_once '../models/SubscriptionModel.php';
        }
    }

    public function plans() {
        $model = new SubscriptionModel();
        $data = [
            'meta_title' => 'Upgrade to Premium | ' . APP_NAME,
            'plans' => $model->getActivePlans(),
            'current_status' => $_SESSION['subscription_status'] ?? 'free'
        ];
        $this->view('subscription/upgrade', $data);
    }

    public function checkout($planId = null) {
        if (!$planId) {
            header("Location: " . APP_URL . "/subscription/plans");
            exit;
        }

        $model = new SubscriptionModel();
        $plan = $model->getPlanById($planId);
        
        if (!$plan) {
            die("Invalid plan selected.");
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Mock transaction generated
            $transactionId = 'TXN_' . strtoupper(uniqid());
            
            if ($model->upgradeUser($_SESSION['user_id'], $planId, $transactionId)) {
                // Update session
                $_SESSION['subscription_status'] = 'premium';
                header("Location: " . APP_URL . "/subscription/success?txn=" . $transactionId);
                exit;
            } else {
                $data['error'] = "Payment processing failed. Please try again.";
            }
        }

        $data['meta_title'] = 'Secure Checkout | ' . APP_NAME;
        $data['plan'] = $plan;
        $this->view('subscription/checkout', $data);
    }

    public function success() {
        if (!isset($_GET['txn'])) {
            header("Location: " . APP_URL . "/dashboard");
            exit;
        }
        $data = [
            'meta_title' => 'Payment Successful | ' . APP_NAME,
            'txn' => $_GET['txn']
        ];
        $this->view('subscription/success', $data);
    }
}
