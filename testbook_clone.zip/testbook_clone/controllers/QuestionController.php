<?php

class QuestionController extends Controller {

    public function __construct() {
        if (!class_exists('QuestionModel')) require_once '../models/QuestionModel.php';
        if (!class_exists('LanguageModel')) require_once '../models/LanguageModel.php';
        if (!class_exists('SeoModel')) require_once '../models/SeoModel.php';
    }

    public function index($slug = '') {
        if (empty($slug)) {
            header("Location: " . APP_URL);
            exit;
        }

        $langModel = new LanguageModel();
        $langCode = defined('APP_LANG') ? APP_LANG : 'en';
        $langId = $langModel->getLanguageIdByCode($langCode);

        $qModel = new QuestionModel();
        $question = $qModel->getQuestionBySlug($slug, $langId);

        if (!$question) {
            die("Question not found.");
        }

        // Breadcrumbs building
        $seoModel = new SeoModel();
        $breadcrumbs = $seoModel->getCategoryBreadcrumbs($question['category_id'], $langId);
        
        // Fetch Quiz Name for breadcrumb
        $quizTitle = getTranslation('quiz_translations', 'quiz_id', $question['quiz_id'], 'title', $langCode);
        $breadcrumbs[] = [
            'url' => APP_URL . '/' . $langCode . '/test/' . $question['quiz_slug'],
            'name' => $quizTitle
        ];
        
        $breadcrumbs[] = [
            'url' => APP_URL . '/' . $langCode . '/question/' . $question['slug'],
            'name' => "Discussion for Q" . $question['id']
        ];

        // Strip HTML for meta tags intelligently safely
        $cleanText = substr(strip_tags($question['question_text']), 0, 150) . '...';

        $data = [
            'question' => $question,
            'meta_title' => "Solution: " . $cleanText . " | " . APP_NAME,
            'meta_description' => "Detailed solution and discussion for '" . $cleanText . "'. Check out the step-by-step logic and options.",
            'canonical_url' => APP_URL . '/en/question/' . $question['slug'], // Defaulting canonical to 'en' strictly avoids duplicate penalties usually
            'breadcrumbs' => $breadcrumbs
        ];

        $this->view('seo/question', $data);
    }
}
