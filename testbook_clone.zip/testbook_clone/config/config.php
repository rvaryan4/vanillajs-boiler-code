<?php
define('APP_NAME', 'Testbook Clone');
define('APP_URL', 'http://localhost/testbook_clone/public');
define('DEFAULT_LANG', 'en');
