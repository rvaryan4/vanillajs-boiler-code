<?php

class SeoModel extends Model {
    
    /**
     * Build breadcrumbs for a given category ID traversing upwards to the root.
     */
    public function getCategoryBreadcrumbs($categoryId, $langId) {
        $breadcrumbs = [];
        $currentId = $categoryId;

        while ($currentId) {
            $stmt = $this->db->prepare("
                SELECT c.id, c.parent_id, c.slug, 
                       COALESCE(ct.name, ct_fallback.name) as name
                FROM categories c
                LEFT JOIN category_translations ct ON c.id = ct.category_id AND ct.language_id = ?
                LEFT JOIN category_translations ct_fallback ON c.id = ct_fallback.category_id AND ct_fallback.language_id = (SELECT id FROM languages WHERE code = 'en')
                WHERE c.id = ?
            ");
            $stmt->execute([$langId, $currentId]);
            $category = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($category) {
                // Prepend so root is first
                array_unshift($breadcrumbs, [
                    'url' => APP_URL . '/' . APP_LANG . '/category/' . $category['slug'],
                    'name' => $category['name']
                ]);
                $currentId = $category['parent_id'];
            } else {
                break;
            }
        }

        // Add typical home root
        array_unshift($breadcrumbs, [
            'url' => APP_URL . '/' . APP_LANG,
            'name' => 'Home'
        ]);

        return $breadcrumbs;
    }
}
