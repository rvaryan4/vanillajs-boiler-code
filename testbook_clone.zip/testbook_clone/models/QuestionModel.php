<?php

class QuestionModel extends Model {

    public function getQuestionBySlug($slug, $langId) {
        $stmt = $this->db->prepare("
            SELECT q.*, 
                   COALESCE(qt.question_text, qt_fallback.question_text) as question_text,
                   COALESCE(qt.explanation, qt_fallback.explanation) as explanation,
                   quiz.slug as quiz_slug,
                   quiz.category_id
            FROM questions q
            LEFT JOIN question_translations qt ON q.id = qt.question_id AND qt.language_id = ?
            LEFT JOIN question_translations qt_fallback ON q.id = qt_fallback.question_id AND qt_fallback.language_id = (SELECT id FROM languages WHERE code = 'en')
            JOIN quizzes quiz ON q.quiz_id = quiz.id
            WHERE q.slug = ?
        ");
        $stmt->execute([$langId, $slug]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

}
