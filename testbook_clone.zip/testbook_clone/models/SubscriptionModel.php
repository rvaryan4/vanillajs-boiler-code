<?php

class SubscriptionModel extends Model {

    public function getActivePlans() {
        return [
            ['id' => 1, 'name' => 'Monthly Pro', 'price' => 199, 'duration_months' => 1, 'features' => ['Unlock all Premium Tests', 'Ad-free Experience', 'Detailed Analytics']],
            ['id' => 2, 'name' => '6-Months Elite', 'price' => 999, 'duration_months' => 6, 'features' => ['Unlock all Premium Tests', 'Ad-free Experience', 'Detailed Analytics', 'Save 17%']],
            ['id' => 3, 'name' => 'Annual Lifetime', 'price' => 1499, 'duration_months' => 12, 'features' => ['Unlock all Premium Tests', 'Ad-free Experience', 'Detailed Analytics', 'Save 37%', 'Priority Support']],
        ];
    }

    public function getPlanById($id) {
        $plans = $this->getActivePlans();
        foreach($plans as $p) {
            if($p['id'] == $id) return $p;
        }
        return null;
    }

    public function upgradeUser($userId, $planId, $transactionId) {
        try {
            $this->db->beginTransaction();

            $plan = $this->getPlanById($planId);
            if(!$plan) throw new Exception("Invalid plan");

            // Update user status
            $stmt = $this->db->prepare("UPDATE users SET subscription_status = 'premium' WHERE id = ?");
            $stmt->execute([$userId]);

            // Insert into user_subscriptions log
            $endDate = date('Y-m-d H:i:s', strtotime("+{$plan['duration_months']} months"));
            $stmtLog = $this->db->prepare("
                INSERT INTO user_subscriptions (user_id, plan_id, transaction_id, start_date, end_date) 
                VALUES (?, ?, ?, NOW(), ?)
            ");
            $stmtLog->execute([$userId, $planId, $transactionId, $endDate]);

            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            return false;
        }
    }
}
