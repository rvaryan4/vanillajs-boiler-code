<?php
class Quiz extends Model {
    public function getRecentPublished($language_id = 1, $limit = 5) {
        $stmt = $this->db->prepare("
            SELECT q.id, q.slug, q.time_limit_minutes, q.total_marks, q.is_premium, 
                   qt.title, qt.description, c.slug as category_slug, ct.name as category_name
            FROM quizzes q
            JOIN quiz_translations qt ON q.id = qt.quiz_id
            JOIN categories c ON q.category_id = c.id
            JOIN category_translations ct ON c.id = ct.category_id AND ct.language_id = qt.language_id
            WHERE q.status = 'published' AND qt.language_id = ?
            ORDER BY q.published_at DESC
            LIMIT ?
        ");
        $stmt->bindValue(1, $language_id, PDO::PARAM_INT);
        $stmt->bindValue(2, $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
