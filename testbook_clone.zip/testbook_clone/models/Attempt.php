<?php
class Attempt extends Model {
    public function getUserAttempts($userId, $limit = 5) {
        $stmt = $this->db->prepare("
            SELECT qa.*, qt.title as quiz_title, q.time_limit_minutes
            FROM quiz_attempts qa
            JOIN quizzes q ON qa.quiz_id = q.id
            LEFT JOIN quiz_translations qt ON q.id = qt.quiz_id AND qt.language_id = 1
            WHERE qa.user_id = ?
            ORDER BY qa.completed_at DESC
            LIMIT ?
        ");
        $stmt->bindValue(1, $userId, PDO::PARAM_INT);
        $stmt->bindValue(2, $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    public function getUserStats($userId) {
        $stmt = $this->db->prepare("
            SELECT 
                COUNT(*) as total_attempts,
                AVG(accuracy_percentage) as avg_accuracy,
                SUM(correct_answers) as total_correct
            FROM quiz_attempts
            WHERE user_id = ?
        ");
        $stmt->execute([$userId]);
        return $stmt->fetch();
    }
}
