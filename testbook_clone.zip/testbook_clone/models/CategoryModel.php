<?php

class CategoryModel extends Model {

    public function getCategoryBySlug($slug, $langId) {
        $stmt = $this->db->prepare("
            SELECT c.*, 
                   COALESCE(ct.name, ct_fallback.name) as name,
                   COALESCE(ct.description, ct_fallback.description) as description,
                   COALESCE(ct.meta_title, ct_fallback.meta_title, ct.name) as meta_title,
                   COALESCE(ct.meta_description, ct_fallback.meta_description, ct.description) as meta_description
            FROM categories c
            LEFT JOIN category_translations ct ON c.id = ct.category_id AND ct.language_id = ?
            LEFT JOIN category_translations ct_fallback ON c.id = ct_fallback.category_id AND ct_fallback.language_id = (SELECT id FROM languages WHERE code = 'en')
            WHERE c.slug = ? AND c.status = 'active'
        ");
        $stmt->execute([$langId, $slug]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getQuizzesByCategory($categoryId, $langId) {
        $stmt = $this->db->prepare("
            SELECT q.id, q.slug, q.time_limit_minutes, q.total_marks, q.is_premium,
                   COALESCE(qt.title, qt_fallback.title) as title,
                   COALESCE(qt.description, qt_fallback.description) as description
            FROM quizzes q
            LEFT JOIN quiz_translations qt ON q.id = qt.quiz_id AND qt.language_id = ?
            LEFT JOIN quiz_translations qt_fallback ON q.id = qt_fallback.quiz_id AND qt_fallback.language_id = (SELECT id FROM languages WHERE code = 'en')
            WHERE q.category_id = ? AND q.status = 'published'
            ORDER BY q.created_at DESC
        ");
        $stmt->execute([$langId, $categoryId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
