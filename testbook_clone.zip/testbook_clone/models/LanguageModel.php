<?php

class LanguageModel extends Model {

    /**
     * Get Language ID from Language Code
     */
    public function getLanguageIdByCode($code) {
        // Simple caching mechanism in memory to avoid repeating queries within the same request
        static $cache = [];
        if (isset($cache[$code])) {
            return $cache[$code];
        }

        $stmt = $this->db->prepare("SELECT id FROM languages WHERE code = ? AND is_active = 1");
        $stmt->execute([$code]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result && isset($result['id'])) {
            $cache[$code] = $result['id'];
            return $result['id'];
        }
        return null;
    }

    /**
     * Fetch all active languages
     */
    public function getActiveLanguages() {
        $stmt = $this->db->query("SELECT id, code, name FROM languages WHERE is_active = 1 ORDER BY is_default DESC, name ASC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get a generic translation value from a translation table with fallback
     */
    public function getTranslationValue($translationTable, $entityColumnName, $entityId, $field, $langCode, $fallbackLang = 'en') {
        $targetLangId = $this->getLanguageIdByCode($langCode);
        
        // Allowed tables to prevent SQL injection (Whitelist)
        $allowedTables = [
            'category_translations',
            'quiz_translations',
            'question_translations',
            'question_option_translations'
        ];

        if (!in_array($translationTable, $allowedTables)) {
            return null;
        }

        if ($targetLangId) {
            $stmt = $this->db->prepare("SELECT `{$field}` FROM `{$translationTable}` WHERE `{$entityColumnName}` = ? AND language_id = ?");
            $stmt->execute([$entityId, $targetLangId]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($result && isset($result[$field]) && !empty(trim($result[$field]))) {
                return $result[$field];
            }
        }

        // Fallback
        if ($langCode !== $fallbackLang) {
            $fallbackLangId = $this->getLanguageIdByCode($fallbackLang);
            if ($fallbackLangId) {
                $stmt = $this->db->prepare("SELECT `{$field}` FROM `{$translationTable}` WHERE `{$entityColumnName}` = ? AND language_id = ?");
                $stmt->execute([$entityId, $fallbackLangId]);
                $result = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($result && isset($result[$field])) {
                    return $result[$field];
                }
            }
        }

        return null;
    }
}
