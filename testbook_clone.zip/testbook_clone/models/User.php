<?php
class User extends Model {
    
    public function register($name, $email, $password, $language_id = 1) {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $this->db->prepare("INSERT INTO users (name, email, password_hash, preferred_language_id) VALUES (?, ?, ?, ?)");
        return $stmt->execute([$name, $email, $hash, $language_id]);
    }
    
    public function findByEmail($email) {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        return $stmt->fetch();
    }
    
    public function createSession($userId, $ip, $userAgent) {
        $sessionId = bin2hex(random_bytes(32));
        $stmt = $this->db->prepare("INSERT INTO user_sessions (session_id, user_id, ip_address, user_agent) VALUES (?, ?, ?, ?)");
        $stmt->execute([$sessionId, $userId, $ip, $userAgent]);
        return $sessionId;
    }
    
    public function destroySession($sessionId) {
        $stmt = $this->db->prepare("DELETE FROM user_sessions WHERE session_id = ?");
        return $stmt->execute([$sessionId]);
    }
}
