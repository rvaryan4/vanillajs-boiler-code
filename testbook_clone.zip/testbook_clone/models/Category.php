<?php
class Category extends Model {
    public function getAllActive($language_id = 1) { 
        $stmt = $this->db->prepare("
            SELECT c.id, c.slug, ct.name, ct.description 
            FROM categories c
            JOIN category_translations ct ON c.id = ct.category_id
            WHERE c.status = 'active' AND ct.language_id = ?
            ORDER BY c.sort_order ASC
        ");
        $stmt->execute([$language_id]);
        return $stmt->fetchAll();
    }
}
