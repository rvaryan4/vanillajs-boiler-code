<?php

class TestSessionModel extends Model {

    /**
     * Start a new test session or resume an existing one.
     */
    public function startOrResumeSession($userId, $quizId, $languageId, $timeLimitSeconds) {
        // Check if an active session exists
        $stmt = $this->db->prepare("SELECT * FROM test_sessions WHERE user_id = ? AND quiz_id = ? AND status IN ('in_progress', 'paused')");
        $stmt->execute([$userId, $quizId]);
        $session = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($session) {
            // Check if time expired
            $elapsed = time() - strtotime($session['last_saved_at']);
            $newTimeRemaining = max(0, $session['time_remaining_seconds'] - $elapsed);
            
            if ($newTimeRemaining <= 0) {
                // Auto-submit if time's up during absence
                $this->submitTest($session['id']);
                return false; // Redirect to result
            }

            // Update remaining time on resume
            $update = $this->db->prepare("UPDATE test_sessions SET status = 'in_progress', time_remaining_seconds = ?, last_saved_at = CURRENT_TIMESTAMP WHERE id = ?");
            $update->execute([$newTimeRemaining, $session['id']]);
            $session['time_remaining_seconds'] = $newTimeRemaining;
            
            return $session;
        }

        // Create new session
        $insert = $this->db->prepare("INSERT INTO test_sessions (user_id, quiz_id, language_id, status, time_remaining_seconds) VALUES (?, ?, ?, 'in_progress', ?)");
        $insert->execute([$userId, $quizId, $languageId, $timeLimitSeconds]);
        $sessionId = $this->db->lastInsertId();

        // Pre-populate responses table as 'not_visited'
        $qm = new QuizModel();
        $questions = $qm->getQuizQuestions($quizId, $languageId);
        
        if (!empty($questions)) {
            $insertResp = $this->db->prepare("INSERT INTO test_session_responses (session_id, question_id, status) VALUES (?, ?, 'not_visited')");
            foreach ($questions as $q) {
                $insertResp->execute([$sessionId, $q['id']]);
            }
        }

        return [
            'id' => $sessionId,
            'time_remaining_seconds' => $timeLimitSeconds
        ];
    }

    /**
     * Save an answer for a question in real-time
     */
    public function saveAnswer($sessionId, $questionId, $selectedOptionId, $status, $timeSpentSeconds) {
        // Enforce valid statuses
        $validStatuses = ['answered', 'marked_for_review', 'answered_marked_for_review', 'not_answered', 'not_visited'];
        if (!in_array($status, $validStatuses)) {
            return false;
        }

        $stmt = $this->db->prepare("
            UPDATE test_session_responses 
            SET selected_option_id = ?, status = ?, time_spent_seconds = time_spent_seconds + ? 
            WHERE session_id = ? AND question_id = ?
        ");
        
        $selectedOptionId = empty($selectedOptionId) ? null : $selectedOptionId;
        return $stmt->execute([$selectedOptionId, $status, $timeSpentSeconds, $sessionId, $questionId]);
    }

    /**
     * Log ping from client to update test time remaining accurately
     */
    public function pingSessionTime($sessionId, $timeRemainingSeconds) {
        $stmt = $this->db->prepare("UPDATE test_sessions SET time_remaining_seconds = ?, last_saved_at = CURRENT_TIMESTAMP WHERE id = ? AND status = 'in_progress'");
        return $stmt->execute([$timeRemainingSeconds, $sessionId]);
    }

    /**
     * Submit a test execution
     */
    public function submitTest($sessionId) {
        $stmt = $this->db->prepare("UPDATE test_sessions SET status = 'submitted', ended_at = CURRENT_TIMESTAMP WHERE id = ?");
        return $stmt->execute([$sessionId]);
    }

    /**
     * Fetch the current state of a session (user's saved answers).
     */
    public function getSessionResponses($sessionId) {
        $stmt = $this->db->prepare("SELECT question_id, selected_option_id, status FROM test_session_responses WHERE session_id = ?");
        $stmt->execute([$sessionId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
