<?php

class AnalyticsModel extends Model {

    /**
     * Gets a summary of all completed tests for a user.
     */
    public function getUserTestHistory($userId) {
        $stmt = $this->db->prepare("
            SELECT ts.id as session_id, ts.start_time, ts.end_time, 
                   q.slug as quiz_slug, qt.title as quiz_title,
                   q.total_marks, q.passing_marks,
                   TIMESTAMPDIFF(SECOND, ts.start_time, ts.end_time) as time_taken_seconds,
                   (SELECT COUNT(*) FROM test_session_responses WHERE session_id = ts.id) as total_attempted,
                   (SELECT COUNT(*) 
                    FROM test_session_responses tsr
                    JOIN question_options qo ON tsr.selected_option_id = qo.id
                    WHERE tsr.session_id = ts.id AND qo.is_correct = 1) as correct_answers,
                   (SELECT SUM(time_spent_seconds) FROM test_session_responses WHERE session_id = ts.id) as pure_time_spent
            FROM test_sessions ts
            JOIN quizzes q ON ts.quiz_id = q.id
            LEFT JOIN quiz_translations qt ON q.id = qt.quiz_id AND qt.language_id = ts.language_id
            WHERE ts.user_id = ? AND ts.status = 'completed'
            ORDER BY ts.end_time DESC
        ");
        $stmt->execute([$userId]);
        $raw = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $history = [];
        foreach($raw as $r) {
            $accuracy = $r['total_attempted'] > 0 ? round(($r['correct_answers'] / $r['total_attempted']) * 100, 2) : 0;
            $history[] = array_merge($r, ['accuracy' => $accuracy]);
        }
        return $history;
    }

    /**
     * Compute global performance averages
     */
    public function getOverallStats($userId) {
        $history = $this->getUserTestHistory($userId);
        
        $totalTests = count($history);
        $totalAttemptedQuestions = 0;
        $totalCorrectAnswers = 0;
        $totalTimeSpent = 0;

        foreach($history as $h) {
            $totalAttemptedQuestions += $h['total_attempted'];
            $totalCorrectAnswers += $h['correct_answers'];
            $totalTimeSpent += $h['pure_time_spent'];
        }

        $overallAccuracy = $totalAttemptedQuestions > 0 ? round(($totalCorrectAnswers / $totalAttemptedQuestions) * 100, 1) : 0;
        $avgTimePerQuestion = $totalAttemptedQuestions > 0 ? round($totalTimeSpent / $totalAttemptedQuestions, 1) : 0;

        return [
            'total_tests' => $totalTests,
            'overall_accuracy' => $overallAccuracy,
            'avg_time_per_question' => $avgTimePerQuestion, // in seconds
            'total_questions_attempted' => $totalAttemptedQuestions
        ];
    }

    /**
     * Look up areas where accuracy dips hardest.
     */
    public function getWeakTopics($userId) {
        $stmt = $this->db->prepare("
            SELECT qn.difficulty,
                   COUNT(tsr.id) as attempts,
                   SUM(CASE WHEN qo.is_correct = 1 THEN 1 ELSE 0 END) as correct
            FROM test_sessions ts
            JOIN test_session_responses tsr ON ts.id = tsr.session_id
            JOIN questions qn ON tsr.question_id = qn.id
            LEFT JOIN question_options qo ON tsr.selected_option_id = qo.id
            WHERE ts.user_id = ? AND ts.status = 'completed' AND tsr.status = 'answered'
            GROUP BY qn.difficulty
        ");
        $stmt->execute([$userId]);
        $raw = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $topics = [];
        foreach($raw as $r) {
            $accuracy = $r['attempts'] > 0 ? round(($r['correct'] / $r['attempts']) * 100, 1) : 0;
            $topics[] = [
                'difficulty' => ucfirst($r['difficulty']),
                'attempts' => $r['attempts'],
                'accuracy' => $accuracy
            ];
        }

        // Sort by lowest accuracy first
        usort($topics, function($a, $b) {
            return $a['accuracy'] <=> $b['accuracy'];
        });

        return $topics;
    }
}
