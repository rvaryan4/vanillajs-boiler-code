<?php

class QuizModel extends Model {

    /**
     * Get a quiz by ID or Slug.
     */
    public function getQuiz($idOrSlug) {
        $field = is_numeric($idOrSlug) ? 'id' : 'slug';
        $stmt = $this->db->prepare("SELECT * FROM quizzes WHERE {$field} = ? AND status = 'published'");
        $stmt->execute([$idOrSlug]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Get all questions for a given quiz ID, including options.
     */
    public function getQuizQuestions($quizId, $langId) {
        // Fetch raw questions
        $stmt = $this->db->prepare("
            SELECT q.id, q.type, q.marks, q.negative_marks,
                   COALESCE(qt.question_text, qt_fallback.question_text) as question_text,
                   COALESCE(qt.explanation, qt_fallback.explanation) as explanation
            FROM questions q
            LEFT JOIN question_translations qt ON q.id = qt.question_id AND qt.language_id = ?
            LEFT JOIN question_translations qt_fallback ON q.id = qt_fallback.question_id AND qt_fallback.language_id = (SELECT id FROM languages WHERE code = 'en')
            WHERE q.quiz_id = ?
            ORDER BY q.sort_order ASC, q.id ASC
        ");
        $stmt->execute([$langId, $quizId]);
        $questions = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (empty($questions)) return [];

        $questionIds = array_column($questions, 'id');
        $inQuery = implode(',', array_fill(0, count($questionIds), '?'));
        
        // Fetch raw options for these questions
        // Note: is_correct should NOT be sent to the frontend API to prevent cheating.
        $optStmt = $this->db->prepare("
            SELECT o.id, o.question_id, o.sort_order,
                   COALESCE(ot.option_text, opt_fallback.option_text) as option_text
            FROM question_options o
            LEFT JOIN question_option_translations ot ON o.id = ot.option_id AND ot.language_id = ?
            LEFT JOIN question_option_translations opt_fallback ON o.id = opt_fallback.option_id AND opt_fallback.language_id = (SELECT id FROM languages WHERE code = 'en')
            WHERE o.question_id IN ($inQuery)
            ORDER BY o.question_id ASC, o.sort_order ASC
        ");
        
        $params = array_merge([$langId], $questionIds);
        $optStmt->execute($params);
        $options = $optStmt->fetchAll(PDO::FETCH_ASSOC);

        // Group options by question
        $optionsByQuestion = [];
        foreach ($options as $opt) {
            $optionsByQuestion[$opt['question_id']][] = [
                'id' => $opt['id'],
                'text' => $opt['option_text']
            ];
        }

        // Attach options
        foreach ($questions as &$q) {
            $q['options'] = $optionsByQuestion[$q['id']] ?? [];
            // Do not expose correct answer info for now
            unset($q['explanation']); // hide explanation during the test
        }

        return $questions;
    }
}
