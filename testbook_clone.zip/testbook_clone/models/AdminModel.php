<?php

class AdminModel extends Model {

    // --- User Management --- //
    public function getUsers() {
        $stmt = $this->db->query("SELECT id, name, email, role, subscription_status, created_at FROM users ORDER BY created_at DESC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function toggleUserSubscription($userId, $status) {
        $stmt = $this->db->prepare("UPDATE users SET subscription_status = ? WHERE id = ?");
        return $stmt->execute([$status, $userId]);
    }

    // --- Category Management --- //
    public function getCategories() {
        $stmt = $this->db->query("
            SELECT c.*, ct.name as default_name 
            FROM categories c
            LEFT JOIN category_translations ct ON c.id = ct.category_id AND ct.language_id = (SELECT id FROM languages WHERE code = 'en')
            ORDER BY c.sort_order ASC
        ");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function addCategory($parentId, $slug, $status, $enName, $enDesc, $hiName, $hiDesc) {
        $parentId = empty($parentId) ? null : $parentId;
        
        try {
            $this->db->beginTransaction();
            
            $stmt = $this->db->prepare("INSERT INTO categories (parent_id, slug, status) VALUES (?, ?, ?)");
            $stmt->execute([$parentId, $slug, $status]);
            $categoryId = $this->db->lastInsertId();

            // English Translation
            $stmtTrans = $this->db->prepare("INSERT INTO category_translations (category_id, language_id, name, description) VALUES (?, (SELECT id FROM languages WHERE code = 'en'), ?, ?)");
            $stmtTrans->execute([$categoryId, $enName, $enDesc]);

            // Hindi Translation (if provided)
            if (!empty($hiName)) {
                $stmtTransHi = $this->db->prepare("INSERT INTO category_translations (category_id, language_id, name, description) VALUES (?, (SELECT id FROM languages WHERE code = 'hi'), ?, ?)");
                $stmtTransHi->execute([$categoryId, $hiName, $hiDesc]);
            }

            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            return false;
        }
    }

    // --- Quiz Management --- //
    public function getQuizzes() {
        $stmt = $this->db->query("
            SELECT q.*, qt.title as default_title, c.slug as category_slug
            FROM quizzes q
            LEFT JOIN quiz_translations qt ON q.id = qt.quiz_id AND qt.language_id = (SELECT id FROM languages WHERE code = 'en')
            LEFT JOIN categories c ON q.category_id = c.id
            ORDER BY q.created_at DESC
        ");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function addQuiz($categoryId, $slug, $timeLimit, $totalMarks, $passingMarks, $isPremium, $status, $enTitle, $enDesc, $hiTitle, $hiDesc) {
        try {
            $this->db->beginTransaction();

            $stmt = $this->db->prepare("INSERT INTO quizzes (category_id, slug, time_limit_minutes, total_marks, passing_marks, is_premium, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$categoryId, $slug, $timeLimit, $totalMarks, $passingMarks, $isPremium, $status]);
            $quizId = $this->db->lastInsertId();

            // English Translation
            $stmtTrans = $this->db->prepare("INSERT INTO quiz_translations (quiz_id, language_id, title, description) VALUES (?, (SELECT id FROM languages WHERE code = 'en'), ?, ?)");
            $stmtTrans->execute([$quizId, $enTitle, $enDesc]);

            // Hindi Translation (if provided)
            if (!empty($hiTitle)) {
                $stmtTransHi = $this->db->prepare("INSERT INTO quiz_translations (quiz_id, language_id, title, description) VALUES (?, (SELECT id FROM languages WHERE code = 'hi'), ?, ?)");
                $stmtTransHi->execute([$quizId, $hiTitle, $hiDesc]);
            }

            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            return false;
        }
    }

    // --- Question Management --- //
    public function getQuestionsByQuiz($quizId) {
        $stmt = $this->db->prepare("
            SELECT q.*, qt.question_text as default_text 
            FROM questions q
            LEFT JOIN question_translations qt ON q.id = qt.question_id AND qt.language_id = (SELECT id FROM languages WHERE code = 'en')
            WHERE q.quiz_id = ?
            ORDER BY q.sort_order ASC
        ");
        $stmt->execute([$quizId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function addQuestion($quizId, $type, $marks, $negMarks, $difficulty, $enText, $hiText, $optionsData) {
        /*
        optionsData format:
        [
            ['is_correct' => 1, 'en_text' => 'A', 'hi_text' => 'अ'],
            ['is_correct' => 0, 'en_text' => 'B', 'hi_text' => 'ब'], ...
        ]
        */
        try {
            $this->db->beginTransaction();

            $stmt = $this->db->prepare("INSERT INTO questions (quiz_id, type, marks, negative_marks, difficulty) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$quizId, $type, $marks, $negMarks, $difficulty]);
            $questionId = $this->db->lastInsertId();

            // Translations
            $stmtTrans = $this->db->prepare("INSERT INTO question_translations (question_id, language_id, question_text) VALUES (?, (SELECT id FROM languages WHERE code = ?), ?)");
            $stmtTrans->execute([$questionId, 'en', $enText]);
            if (!empty($hiText)) {
                $stmtTrans->execute([$questionId, 'hi', $hiText]);
            }

            // Options
            $stmtOpt = $this->db->prepare("INSERT INTO question_options (question_id, is_correct, sort_order) VALUES (?, ?, ?)");
            $stmtOptTrans = $this->db->prepare("INSERT INTO question_option_translations (option_id, language_id, option_text) VALUES (?, (SELECT id FROM languages WHERE code = ?), ?)");

            foreach ($optionsData as $idx => $opt) {
                $stmtOpt->execute([$questionId, $opt['is_correct'], $idx]);
                $optionId = $this->db->lastInsertId();

                $stmtOptTrans->execute([$optionId, 'en', $opt['en_text']]);
                if (!empty($opt['hi_text'])) {
                    $stmtOptTrans->execute([$optionId, 'hi', $opt['hi_text']]);
                }
            }

            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            return false;
        }
    }
}
