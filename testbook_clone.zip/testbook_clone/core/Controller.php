<?php
class Controller {
    public function model($model) {
        if (file_exists('../models/' . $model . '.php')) {
            require_once '../models/' . $model . '.php';
            return new $model();
        }
        die("Model $model not found.");
    }

    public function view($view, $data = []) {
        if (file_exists('../views/' . $view . '.php')) {
            // Load language file
            $lang_code = $_SESSION['lang'] ?? DEFAULT_LANG;
            $lang = [];
            if (file_exists('../language/' . $lang_code . '/messages.php')) {
                $lang = require '../language/' . $lang_code . '/messages.php';
            }
            $data['lang'] = $lang;
            
            extract($data);
            require_once '../views/' . $view . '.php';
        } else {
            die("View $view not found.");
        }
    }

    public function redirect($url) {
        header('Location: ' . APP_URL . $url);
        exit;
    }
}
