<?php
class Auth {
    // Middleware: Ensure user is authenticated
    public static function check() {
        if (!isset($_SESSION['user_id'])) {
            header('Location: ' . APP_URL . '/auth/login');
            exit;
        }
    }

    // Middleware: Ensure user is NOT authenticated (e.g., login pages)
    public static function guest() {
        if (isset($_SESSION['user_id'])) {
            header('Location: ' . APP_URL . '/dashboard');
            exit;
        }
    }
    
    // CSRF Protection: Generate
    public static function generateCSRF() {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
    
    // CSRF Protection: Verify
    public static function verifyCSRF($token) {
        if (!isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
            die("CSRF token validation failed. Suspicious activity detected.");
        }
    }
}
