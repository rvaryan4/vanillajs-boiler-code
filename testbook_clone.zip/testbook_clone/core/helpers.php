<?php

/**
 * Global helper functions for the Testbook Clone application.
 */

if (!function_exists('getTranslation')) {
    /**
     * Fetch a translation for a specific entity from a given translation table.
     *
     * @param string $translationTable The name of the translation table (e.g., 'question_translations').
     * @param string $entityColumnName The column name connecting to the main entity (e.g., 'question_id').
     * @param int $entityId The ID of the primary entity.
     * @param string $field The field to fetch (e.g., 'question_text').
     * @param string $langCode The target language code. Defaults to APP_LANG.
     * @param string $fallbackLang The fallback language code (e.g., 'en').
     * @return string|null The translated string or null if not found.
     */
    function getTranslation($translationTable, $entityColumnName, $entityId, $field, $langCode = null, $fallbackLang = 'en') {
        if ($langCode === null) {
            $langCode = defined('APP_LANG') ? APP_LANG : 'en';
        }

        require_once 'app/models/LanguageModel.php'; // ensure this path makes sense or rely on autoloader
        // For our simple MVC without PSR-4 autoloader:
        if (!class_exists('LanguageModel')) {
            require_once __DIR__ . '/../models/LanguageModel.php';
        }

        $languageModel = new LanguageModel();
        return $languageModel->getTranslationValue($translationTable, $entityColumnName, $entityId, $field, $langCode, $fallbackLang);
    }
}

if (!function_exists('requirePremiumAccess')) {
    /**
     * Checks if a user is trying to access a premium quiz without a premium subscription.
     * Redirects to the upgrade page if access is denied.
     *
     * @param int $quizId The ID of the quiz being accessed.
     */
    function requirePremiumAccess($quizId) {
        if (!class_exists('QuizModel')) {
            require_once __DIR__ . '/../models/QuizModel.php';
        }
        $quizModel = new QuizModel();
        $quiz = $quizModel->getQuiz($quizId);

        if ($quiz && $quiz['is_premium']) {
            if (!isset($_SESSION['user_id'])) {
                header("Location: " . APP_URL . "/auth/login?redirect=subscription/plans");
                exit;
            }

            if (!isset($_SESSION['subscription_status']) || $_SESSION['subscription_status'] !== 'premium') {
                header("Location: " . APP_URL . "/subscription/plans?access=denied");
                exit;
            }
        }
    }
}

if (!function_exists('e')) {
    /**
     * Escape HTML entities to prevent XSS universally.
     */
    function e($string) {
        return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('generateCsrfToken')) {
    /**
     * Generates a CSRF token and sets it in the session if it doesn't exist.
     */
    function generateCsrfToken() {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
}

if (!function_exists('verifyCsrfToken')) {
    /**
     * Verifies the provided CSRF token against the session.
     */
    function verifyCsrfToken($token) {
        if (!isset($_SESSION['csrf_token']) || empty($token)) {
            return false;
        }
        return hash_equals($_SESSION['csrf_token'], $token);
    }
}
