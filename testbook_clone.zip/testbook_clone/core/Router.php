<?php
class Router {
    protected $controller = 'AuthController';
    protected $method = 'login';
    protected $params = [];

    public function __construct() {
        $url = $this->parseUrl();

        if (isset($url[0])) {
            // Handle language prefix (e.g., /en/login vs /login)
            if (strlen($url[0]) === 2) {
                $_SESSION['lang'] = $url[0];
                unset($url[0]);
                $url = array_values($url);
            }
        }

        $lang = $_SESSION['lang'] ?? 'en';
        if (!defined('APP_LANG')) {
            define('APP_LANG', $lang);
        }

        if (isset($url[0])) {
            $controllerName = ucfirst($url[0]) . 'Controller';
            if (file_exists('../controllers/' . $controllerName . '.php')) {
                $this->controller = $controllerName;
                unset($url[0]);
            }
        }

        require_once '../controllers/' . $this->controller . '.php';
        $this->controller = new $this->controller;

        if (isset($url[1])) {
            if (method_exists($this->controller, $url[1])) {
                $this->method = $url[1];
                unset($url[1]);
            }
        }

        // Handle case where URL has no segments to keep default method routing safe
        if (!method_exists($this->controller, $this->method)) {
            $this->method = 'index'; // Fallback
        }

        $this->params = $url ? array_values($url) : [];

        // Enforce strict global CSRF Security on all POST requests
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            require_once '../core/helpers.php';
            $token = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
            
            if (!verifyCsrfToken($token)) {
                $isApi = isset($_SERVER['HTTP_X_CSRF_TOKEN']) || (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest');
                if ($isApi) {
                    header('Content-Type: application/json');
                    http_response_code(403);
                    echo json_encode(['error' => 'CSRF mismatch or expiration. Action blocked.']);
                    exit;
                } else {
                    die('CSRF Token Validation Failed. Please refresh the page and try again securely.');
                }
            }
        }

        call_user_func_array([$this->controller, $this->method], $this->params);
    }

    public function parseUrl() {
        if (isset($_GET['url'])) {
            return explode('/', filter_var(rtrim($_GET['url'], '/'), FILTER_SANITIZE_URL));
        }
        return [];
    }
}
