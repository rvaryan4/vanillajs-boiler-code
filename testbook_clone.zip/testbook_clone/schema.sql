-- Testbook Clone Schema (Multilingual, Scalable, Production-Grade)
CREATE DATABASE IF NOT EXISTS testbook_clone CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE testbook_clone;

-- 1. Languages
CREATE TABLE languages (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(10) NOT NULL UNIQUE, -- e.g., 'en', 'es', 'hi'
    name VARCHAR(50) NOT NULL,
    is_default BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Users
CREATE TABLE users (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin', 'moderator') DEFAULT 'user',
    subscription_status ENUM('free', 'premium') DEFAULT 'free',
    preferred_language_id INT UNSIGNED,
    timezone VARCHAR(50) DEFAULT 'UTC',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (preferred_language_id) REFERENCES languages(id) ON DELETE SET NULL,
    INDEX idx_email (email),
    INDEX idx_role (role)
);

-- Active User Sessions (for secure login enforcement)
CREATE TABLE user_sessions (
    session_id VARCHAR(128) PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    ip_address VARCHAR(45),
    user_agent TEXT,
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_last_activity (last_activity)
);

-- 3. Categories (Parent-Child Hierarchy & SEO friendly routes)
CREATE TABLE categories (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    parent_id INT UNSIGNED DEFAULT NULL,
    slug VARCHAR(255) NOT NULL UNIQUE,
    status ENUM('active', 'inactive') DEFAULT 'active',
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE SET NULL,
    INDEX idx_parent (parent_id),
    INDEX idx_slug (slug),
    INDEX idx_status_sort (status, sort_order)
);

CREATE TABLE category_translations (
    category_id INT UNSIGNED NOT NULL,
    language_id INT UNSIGNED NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    meta_title VARCHAR(255),       -- SEO
    meta_description TEXT,         -- SEO
    PRIMARY KEY (category_id, language_id),
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
    FOREIGN KEY (language_id) REFERENCES languages(id) ON DELETE CASCADE
);

-- 4. Quizzes / Tests
CREATE TABLE quizzes (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    category_id INT UNSIGNED NOT NULL,
    slug VARCHAR(255) NOT NULL UNIQUE,
    time_limit_minutes INT NOT NULL,
    total_marks DECIMAL(8,2) NOT NULL DEFAULT 0.00,
    passing_marks DECIMAL(8,2) NOT NULL DEFAULT 0.00,
    is_premium BOOLEAN DEFAULT FALSE,
    status ENUM('draft', 'published', 'archived') DEFAULT 'draft',
    published_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
    INDEX idx_category_status (category_id, status),
    INDEX idx_slug (slug)
);

CREATE TABLE quiz_translations (
    quiz_id BIGINT UNSIGNED NOT NULL,
    language_id INT UNSIGNED NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    instructions TEXT,             -- specific test instructions pre-exam
    meta_title VARCHAR(255),       -- SEO
    meta_description TEXT,         -- SEO
    PRIMARY KEY (quiz_id, language_id),
    FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE,
    FOREIGN KEY (language_id) REFERENCES languages(id) ON DELETE CASCADE
);

-- 5. Questions
CREATE TABLE questions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    quiz_id BIGINT UNSIGNED NOT NULL,
    slug VARCHAR(255) UNIQUE,      -- SEO for individual question discussion/solution pages
    type ENUM('multiple_choice', 'multiple_response', 'true_false') DEFAULT 'multiple_choice',
    marks DECIMAL(5,2) DEFAULT 1.00,
    negative_marks DECIMAL(5,2) DEFAULT 0.00,
    difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'medium',
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE,
    INDEX idx_quiz_sort (quiz_id, sort_order)
);

CREATE TABLE question_translations (
    question_id BIGINT UNSIGNED NOT NULL,
    language_id INT UNSIGNED NOT NULL,
    question_text TEXT NOT NULL,
    explanation TEXT,              -- Shown in analytics/review phase
    PRIMARY KEY (question_id, language_id),
    FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE,
    FOREIGN KEY (language_id) REFERENCES languages(id) ON DELETE CASCADE
);

-- 6. Question Options
CREATE TABLE question_options (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    question_id BIGINT UNSIGNED NOT NULL,
    is_correct BOOLEAN DEFAULT FALSE,
    sort_order INT DEFAULT 0,
    FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE,
    INDEX idx_question (question_id)
);

CREATE TABLE question_option_translations (
    option_id BIGINT UNSIGNED NOT NULL,
    language_id INT UNSIGNED NOT NULL,
    option_text TEXT NOT NULL,
    PRIMARY KEY (option_id, language_id),
    FOREIGN KEY (option_id) REFERENCES question_options(id) ON DELETE CASCADE,
    FOREIGN KEY (language_id) REFERENCES languages(id) ON DELETE CASCADE
);

-- 7. Test Sessions (For maintaining state during the active exam)
CREATE TABLE test_sessions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    quiz_id BIGINT UNSIGNED NOT NULL,
    language_id INT UNSIGNED NOT NULL, -- Language the test was taken in
    status ENUM('in_progress', 'paused', 'submitted', 'auto_submitted') DEFAULT 'in_progress',
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ended_at TIMESTAMP NULL,
    time_remaining_seconds INT NOT NULL,
    last_saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE,
    FOREIGN KEY (language_id) REFERENCES languages(id) ON DELETE RESTRICT,
    INDEX idx_user_quiz (user_id, quiz_id),
    INDEX idx_status (status)
);

-- Responses saved dynamically during a test session
CREATE TABLE test_session_responses (
    session_id BIGINT UNSIGNED NOT NULL,
    question_id BIGINT UNSIGNED NOT NULL,
    selected_option_id BIGINT UNSIGNED DEFAULT NULL,
    status ENUM('answered', 'marked_for_review', 'answered_marked_for_review', 'not_answered', 'not_visited') DEFAULT 'not_visited',
    time_spent_seconds INT DEFAULT 0,
    PRIMARY KEY (session_id, question_id),
    FOREIGN KEY (session_id) REFERENCES test_sessions(id) ON DELETE CASCADE,
    FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE,
    FOREIGN KEY (selected_option_id) REFERENCES question_options(id) ON DELETE SET NULL
);

-- 8. Quiz Attempts (Final analytics & performance logic processed AFTER session submit)
CREATE TABLE quiz_attempts (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    session_id BIGINT UNSIGNED NOT NULL UNIQUE,
    user_id BIGINT UNSIGNED NOT NULL,
    quiz_id BIGINT UNSIGNED NOT NULL,
    total_score DECIMAL(8,2) NOT NULL DEFAULT 0.00,
    accuracy_percentage DECIMAL(5,2) DEFAULT 0.00,
    total_questions INT NOT NULL,
    attempted_questions INT DEFAULT 0,
    correct_answers INT DEFAULT 0,
    incorrect_answers INT DEFAULT 0,
    time_taken_seconds INT NOT NULL,
    completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES test_sessions(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE,
    INDEX idx_user_quiz_attempts (user_id, quiz_id)
);
