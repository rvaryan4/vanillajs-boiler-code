<?php require_once '../views/layouts/header.php'; ?>
<div class="auth-container">
    <div class="auth-card shadow-lg">
        <div class="auth-header text-center">
            <h2><?php echo $lang['login_title'] ?? 'Login'; ?></h2>
            <p class="text-muted">Welcome back! Please enter your details.</p>
        </div>
        
        <?php if(isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; // contains raw HTML breaks ?></div>
        <?php endif; ?>
        <?php if(isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <form action="<?php echo APP_URL; ?>/auth/login" method="POST" class="auth-form">
            <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token ?? ''); ?>">
            
            <div class="form-group">
                <label for="email"><?php echo $lang['email'] ?? 'Email Address'; ?></label>
                <input type="email" name="email" id="email" class="form-control" required placeholder="Enter your email">
            </div>
            <div class="form-group">
                <label for="password"><?php echo $lang['password'] ?? 'Password'; ?></label>
                <input type="password" name="password" id="password" class="form-control" required placeholder="Enter your password">
            </div>
            <div class="form-options">
                <label class="custom-checkbox">
                    <input type="checkbox" name="remember">
                    <span>Remember me</span>
                </label>
                <a href="#" class="forgot-link">Forgot Password?</a>
            </div>
            <button type="submit" class="btn btn-primary btn-block"><?php echo $lang['login_btn'] ?? 'Login'; ?></button>
        </form>
        
        <div class="auth-footer text-center mt-4">
            <p><?php echo $lang['no_account'] ?? 'Don\'t have an account?'; ?> <a href="<?php echo APP_URL; ?>/auth/register" class="text-primary font-weight-bold"><?php echo $lang['register_btn'] ?? 'Sign up'; ?></a></p>
        </div>
    </div>
</div>
<?php require_once '../views/layouts/footer.php'; ?>
