<?php require_once '../views/layouts/header.php'; ?>
<div class="auth-container">
    <div class="auth-card shadow-lg">
        <div class="auth-header text-center">
            <h2><?php echo $lang['register_title'] ?? 'Create an Account'; ?></h2>
            <p class="text-muted">Start your preparation journey today.</p>
        </div>
        
        <?php if(isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; // outputs handled html errors from AuthController ?></div>
        <?php endif; ?>

        <form action="<?php echo APP_URL; ?>/auth/register" method="POST" class="auth-form">
            <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token ?? ''); ?>">
            
            <div class="form-group">
                <label for="name"><?php echo $lang['name'] ?? 'Full Name'; ?></label>
                <input type="text" name="name" id="name" class="form-control" required placeholder="Enter your full name (Min 3 chars)">
            </div>
            <div class="form-group">
                <label for="email"><?php echo $lang['email'] ?? 'Email Address'; ?></label>
                <input type="email" name="email" id="email" class="form-control" required placeholder="Enter your email">
            </div>
            <div class="form-group">
                <label for="language_id">Preferred Interface Language</label>
                <select name="language_id" id="language_id" class="form-control">
                    <option value="1">English (EN)</option>
                    <option value="2">Hindi (HI)</option>
                </select>
            </div>
            <div class="form-group">
                <label for="password"><?php echo $lang['password'] ?? 'Password'; ?></label>
                <input type="password" name="password" id="password" class="form-control" required placeholder="Create a password (Min 8 chars)">
            </div>
            <button type="submit" class="btn btn-primary btn-block"><?php echo $lang['register_btn'] ?? 'Sign Up'; ?></button>
        </form>
        
        <div class="auth-footer text-center mt-4">
            <p><?php echo $lang['have_account'] ?? 'Already have an account?'; ?> <a href="<?php echo APP_URL; ?>/auth/login" class="text-primary font-weight-bold"><?php echo $lang['login_btn'] ?? 'Login'; ?></a></p>
        </div>
    </div>
</div>
<?php require_once '../views/layouts/footer.php'; ?>
