<?php require_once '../views/layouts/header.php'; ?>

<style>
.quiz-container { max-width: 800px; margin: 40px auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
.instructions-list li { margin-bottom: 10px; line-height: 1.6; }
</style>

<div class="quiz-container">
    <h2><?php echo htmlspecialchars($data['quiz']['title'] ?? 'Mock Test'); ?> - Instructions</h2>
    <hr style="margin: 20px 0; border: 0; border-top: 1px solid #eee;">
    
    <div style="background: #f8f9fa; padding: 15px; border-radius: 6px; margin-bottom: 20px;">
        <p><strong>Duration:</strong> <?php echo $data['quiz']['time_limit_minutes']; ?> Minutes</p>
        <p><strong>Total Marks:</strong> <?php echo $data['quiz']['total_marks']; ?></p>
        <p><strong>Passing Marks:</strong> <?php echo $data['quiz']['passing_marks']; ?></p>
    </div>

    <h3>Please read the following instructions carefully:</h3>
    <ul class="instructions-list" style="margin-top: 15px;">
        <li>The clock will be set at the server. The countdown timer in the top right corner of screen will display the remaining time available for you to complete the examination.</li>
        <li>When the timer reaches zero, the examination will end by itself. You will not be required to end or submit your examination.</li>
        <li>The Question Palette displayed on the right side of screen will show the status of each question using colors.</li>
        <li>You can navigate to any question by clicking the question number in the Question Palette.</li>
        <li>Click on <strong>Save & Next</strong> to save your answer for the current question and then go to the next question.</li>
        <li>Click on <strong>Mark for Review & Next</strong> to save your answer for the current question, mark it for review, and then go to the next question.</li>
    </ul>

    <div style="margin-top: 30px; text-align: center;">
        <a href="<?php echo APP_URL; ?>/quiz/config/<?php echo $data['quiz']['id']; ?>" class="btn btn-primary" style="padding: 12px 24px; font-size: 16px;">Next</a>
    </div>
</div>

<?php require_once '../views/layouts/footer.php'; ?>
