<?php require_once '../views/layouts/header.php'; ?>

<style>
.quiz-container { max-width: 800px; margin: 40px auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
</style>

<div class="quiz-container">
    <h2><?php echo htmlspecialchars($data['quiz']['title'] ?? 'Mock Test'); ?></h2>
    <hr style="margin: 20px 0; border: 0; border-top: 1px solid #eee;">
    
    <form action="<?php echo APP_URL; ?>/quiz/interface/<?php echo $data['quiz']['id']; ?>" method="POST" id="configForm">
        <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
        
        <div style="margin-bottom: 25px;">
            <label style="display: block; font-weight: 600; margin-bottom: 10px; font-size: 16px;">Choose your default language:</label>
            <select name="language" style="width: 100%; max-width: 300px; padding: 10px; border: 1px solid #ccc; border-radius: 4px;" required>
                <?php foreach($data['languages'] as $lang): ?>
                    <option value="<?php echo $lang['code']; ?>" <?php echo (defined('APP_LANG') && APP_LANG == $lang['code']) ? 'selected' : ''; ?>>
                        <?php echo $lang['name']; ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <p style="font-size: 13px; color: #666; margin-top: 5px;">You can change your default language during the exam.</p>
        </div>

        <div style="background: #e6ffed; border: 1px solid #b3f0c2; padding: 20px; border-radius: 6px; margin-bottom: 25px;">
            <label style="display: flex; align-items: flex-start; cursor: pointer;">
                <input type="checkbox" id="declaration" required style="margin-top: 4px; margin-right: 15px; transform: scale(1.2);">
                <span style="font-size: 14px; line-height: 1.5; color: #333;">
                    I have read and understood the instructions. All computer hardware allotted to me are in proper working condition. I strictly agree that I will not carry any prohibited items into the exam hall. I agree that in case of not adhering to the instructions, I will be disqualified.
                </span>
            </label>
        </div>

        <div style="text-align: center;">
            <button type="submit" class="btn btn-primary" id="startBtn" disabled style="padding: 14px 40px; font-size: 18px; font-weight: bold; background-color: #007bff; border: none;">I am ready to begin</button>
        </div>
    </form>
</div>

<script>
document.getElementById('declaration').addEventListener('change', function() {
    document.getElementById('startBtn').disabled = !this.checked;
    if(this.checked) {
        document.getElementById('startBtn').style.opacity = '1';
        document.getElementById('startBtn').style.cursor = 'pointer';
    } else {
        document.getElementById('startBtn').style.opacity = '0.6';
        document.getElementById('startBtn').style.cursor = 'not-allowed';
    }
});
// Trigger initially
document.getElementById('declaration').dispatchEvent(new Event('change'));
</script>

<?php require_once '../views/layouts/footer.php'; ?>
