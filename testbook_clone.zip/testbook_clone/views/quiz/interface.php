<!DOCTYPE html>
<html lang="<?php echo $_SESSION['quiz_lang'] ?? 'en'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Interface - <?php echo htmlspecialchars($data['quiz']['title']); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/css/quiz.css">
</head>
<body>

<div class="quiz-header">
    <h1><?php echo htmlspecialchars($data['quiz']['title']); ?></h1>
    <div class="timer" id="timerDisplay">
        Time Left: 00:00:00
    </div>
</div>

<div class="main-layout">
    <!-- Left Panel: Question Display -->
    <div class="left-panel">
        <div class="question-area" id="questionArea">
            <h3 id="questionNumber">Question 1</h3>
            <div class="question-text" id="questionText">Loading question...</div>
            <ul class="options-list" id="optionsList">
                <!-- Options injected via JS -->
            </ul>
        </div>
        
        <div class="action-bar">
            <div>
                <button class="btn-action btn-clear" id="btnMarkReview">Mark for Review & Next</button>
                <button class="btn-action btn-clear" id="btnClearResponse" style="margin-left: 10px;">Clear Response</button>
            </div>
            <div>
                <button class="btn-action btn-save-next" id="btnSaveNext">Save & Next</button>
            </div>
        </div>
    </div>

    <!-- Right Panel: Status & Navigation -->
    <div class="right-panel">
        <div class="profile-section">
            <img src="https://ui-avatars.com/api/?name=User&background=random" alt="User" style="width: 40px; height: 40px; border-radius: 50%; margin-right: 15px;">
            <div>
                <strong style="display: block;">Candidate</strong>
                <span style="font-size: 13px; color: #666;">Mock Test</span>
            </div>
        </div>

        <div class="palette-status">
            <div class="status-badge badge-answered"><div class="status-circle" id="countAnswered">0</div> Answered</div>
            <div class="status-badge badge-not-answered"><div class="status-circle" id="countNotAnswered">0</div> Not Answered</div>
            <div class="status-badge badge-not-visited"><div class="status-circle" id="countNotVisited">0</div> Not Visited</div>
            <div class="status-badge badge-review"><div class="status-circle" id="countReview">0</div> Marked for Review</div>
            <div class="status-badge badge-answered-review" style="grid-column: span 2;"><div class="status-circle" id="countAnsReview">0</div> Answered & Marked for Review</div>
        </div>

        <div class="grid-area">
            <h4 style="margin-top: 0;">Section</h4>
            <div class="question-grid" id="questionGrid">
                <!-- Grid buttons injected via JS -->
            </div>
        </div>

        <div class="right-panel-footer">
            <button class="btn-submit" id="btnSubmitTest">Submit Test</button>
        </div>
    </div>
</div>

<script>
    // Pass config to JS engine
    window.QUIZ_CONFIG = {
        quizId: <?php echo $data['quiz']['id']; ?>,
        langId: <?php echo $data['lang_id']; ?>,
        timeRemainingSeconds: <?php echo $data['session']['time_remaining_seconds']; ?>,
        apiUrl: '<?php echo APP_URL; ?>/api',
        baseUrl: '<?php echo APP_URL; ?>'
    };
</script>
<script src="<?php echo APP_URL; ?>/js/quiz_engine.js"></script>
</body>
</html>
