<?php require_once '../views/layouts/header.php'; ?>
<div class="dashboard-layout">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="user-profile text-center mb-4">
            <div class="avatar"><?php echo strtoupper(substr($_SESSION['user_name'], 0, 1)); ?></div>
            <h4 class="mt-2 text-dark"><?php echo htmlspecialchars($_SESSION['user_name']); ?></h4>
            <span class="badge badge-<?php echo $_SESSION['user_role'] == 'premium' ? 'warning' : 'info'; ?>">
                <?php echo ucfirst($_SESSION['user_role'] ?? 'Free'); ?> User
            </span>
        </div>
        <ul class="nav-menu">
            <li><a href="<?php echo APP_URL; ?>/dashboard" class="active"><i class="icon-home"></i> Home</a></li>
            <li><a href="<?php echo APP_URL; ?>/tests"><i class="icon-book"></i> My Tests</a></li>
            <li><a href="<?php echo APP_URL; ?>/analytics"><i class="icon-chart"></i> Analytics</a></li>
            <li><a href="<?php echo APP_URL; ?>/profile"><i class="icon-user"></i> Profile</a></li>
        </ul>
        
        <div class="sidebar-promo mt-4">
            <h5>Upgrade to Premium</h5>
            <p class="text-xs text-muted">Get access to 500+ mock tests</p>
            <a href="<?php echo APP_URL; ?>/subscription" class="btn btn-primary btn-block btn-sm mt-2">View Plans</a>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="dashboard-main">
        <header class="dashboard-header mb-4">
            <h2>Welcome back, <?php echo htmlspecialchars(explode(' ', $_SESSION['user_name'])[0]); ?>! 👋</h2>
            <p class="text-muted">Here is your preparation summary.</p>
        </header>

        <!-- Stats Overview -->
        <div class="stats-grid mb-4">
            <div class="stat-card">
                <div class="stat-icon bg-blue-light text-primary">📝</div>
                <div class="stat-details">
                    <h3><?php echo $stats['total_attempts'] ?? 0; ?></h3>
                    <p class="text-muted">Tests Attempted</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon bg-green-light text-success">🎯</div>
                <div class="stat-details">
                    <h3><?php echo number_format($stats['avg_accuracy'] ?? 0, 1); ?>%</h3>
                    <p class="text-muted">Avg. Accuracy</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon bg-orange-light text-warning">✅</div>
                <div class="stat-details">
                    <h3><?php echo $stats['total_correct'] ?? 0; ?></h3>
                    <p class="text-muted">Correct Answers</p>
                </div>
            </div>
        </div>

        <!-- Two column layout -->
        <div class="content-split">
            <!-- Left Column: New Tests -->
            <div class="dashboard-col flex-2">
                <div class="section-header">
                    <h3>Recommended Tests</h3>
                    <a href="<?php echo APP_URL; ?>/tests" class="text-primary font-weight-bold view-all">View All</a>
                </div>
                
                <div class="test-list mt-3">
                    <?php if(empty($recent_quizzes)): ?>
                        <div class="empty-state text-center p-4 alert-info border rounded">
                            <p>No tests available yet in your selected language.</p>
                        </div>
                    <?php else: ?>
                        <?php foreach($recent_quizzes as $quiz): ?>
                            <div class="test-card">
                                <div class="test-info">
                                    <span class="category-tag"><?php echo htmlspecialchars($quiz['category_name'] ?? 'General'); ?></span>
                                    <h4><?php echo htmlspecialchars($quiz['title']); ?></h4>
                                    <div class="test-meta text-muted mt-1">
                                        <span>⏱ <?php echo $quiz['time_limit_minutes']; ?> mins</span> • 
                                        <span>💯 <?php echo $quiz['total_marks']; ?> marks</span>
                                    </div>
                                </div>
                                <div class="test-actions">
                                    <?php if($quiz['is_premium'] && (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'premium')): ?>
                                        <button class="btn btn-outline btn-locked" disabled>🔒 Premium</button>
                                    <?php else: ?>
                                        <a href="<?php echo APP_URL; ?>/quiz/start/<?php echo $quiz['id']; ?>" class="btn btn-outline btn-start">Start Test</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Right Column: Recent Activity -->
            <div class="dashboard-col flex-1">
                <div class="section-header">
                    <h3>Recent Attempts</h3>
                </div>
                
                <div class="activity-list mt-3">
                    <?php if(empty($recent_attempts)): ?>
                        <div class="empty-state text-center p-4 border rounded">
                            <p class="text-muted text-sm">You haven't attempted any tests yet.</p>
                        </div>
                    <?php else: ?>
                        <?php foreach($recent_attempts as $attempt): ?>
                            <div class="activity-card mb-3 p-3 border rounded border-left-success">
                                <h5 class="text-dark m-0 pb-1"><?php echo htmlspecialchars($attempt['quiz_title']); ?></h5>
                                <div class="d-flex justify-content-between mt-2 text-sm">
                                    <span class="text-success font-weight-bold">Score: <?php echo $attempt['total_score']; ?></span>
                                    <span class="text-muted"><?php echo number_format($attempt['accuracy_percentage'], 1); ?>% Acc</span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
</div>

<style>
/* Dashboard Layout Elements */
body { background: #f8f9fa; }
.dashboard-layout { display: flex; min-height: calc(100vh - 66px); }
.sidebar { width: 250px; background: #fff; padding: 2rem 1.5rem; border-right: 1px solid #eaeaea; }
.dashboard-main { flex: 1; padding: 2.5rem; overflow-y: auto; }

/* Nav Menu Override for Dashboard sidebar */
.nav-menu { list-style: none; padding: 0; margin-top: 2rem; }
.nav-menu li { margin-bottom: 0.5rem; }
.nav-menu a { display: block; padding: 0.75rem 1rem; color: #5f6368; text-decoration: none; border-radius: 6px; font-weight: 500; transition: all 0.2s; margin-left: 0; }
.nav-menu a:hover, .nav-menu a.active { background: #f1f3f4; color: var(--primary-color); }

/* Avatar */
.avatar { width: 64px; height: 64px; border-radius: 50%; background: var(--primary-color); color: white; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; font-weight: bold; margin: 0 auto; }
.badge { padding: 4px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: 600; display: inline-block; }
.badge-warning { background: #fff3cd; color: #856404; }
.badge-info { background: #d1ecf1; color: #0c5460; }

/* Promo */
.sidebar-promo { background: #f8fbff; border: 1px solid #d2e3fc; padding: 1.25rem; border-radius: 8px; text-align: center; }
.text-xs { font-size: 0.8rem; }
.btn-sm { padding: 0.5rem 1rem; font-size: 0.85rem; }

/* Stats Grid */
.stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1.5rem; }
.stat-card { background: #fff; padding: 1.5rem; border-radius: 12px; display: flex; align-items: center; box-shadow: 0 1px 3px rgba(0,0,0,0.05); border: 1px solid #f1f3f4; }
.stat-icon { width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; margin-right: 1rem; }
.bg-blue-light { background: #e8f0fe; }
.bg-green-light { background: #e6f4ea; }
.bg-orange-light { background: #fef0e5; }
.stat-details h3 { margin-bottom: 0; font-size: 1.5rem; font-weight: 700; color: #202124; }
.stat-details p { margin-bottom: 0; font-size: 0.85rem; }

/* Split Layout */
.content-split { display: flex; gap: 2rem; }
.flex-2 { flex: 2; width: 60%; }
.flex-1 { flex: 1; width: 40%;}
.section-header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #f1f3f4; padding-bottom: 0.75rem; }
.section-header h3 { font-size: 1.1rem; color: #202124; margin: 0; }
.view-all { font-size: 0.85rem; text-decoration: none; }

/* Test Cards */
.test-card { display: flex; justify-content: space-between; align-items: center; background: #fff; padding: 1.25rem; border-radius: 8px; border: 1px solid #f1f3f4; margin-bottom: 1rem; box-shadow: 0 1px 2px rgba(0,0,0,0.02); transition: box-shadow 0.2s; }
.test-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
.category-tag { font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.5px; color: #1a73e8; background: #e8f0fe; padding: 3px 8px; border-radius: 4px; font-weight: 600; display: inline-block; margin-bottom: 0.5rem; }
.test-info h4 { font-size: 1.05rem; margin: 0; color: #202124; }
.test-meta { font-size: 0.85rem; }
.btn-start { border-color: #17bb84; color: #17bb84; }
.btn-start:hover { background: #17bb84; color: #fff; border-color: #17bb84; }
.btn-locked { background: #f8f9fa; border-color: #dadce0; color: #9aa0a6; cursor: not-allowed; }

/* Utilities */
.alert-info { background: #e8f0fe; border-color: #d2e3fc; color: #1a73e8; }
.mb-3 { margin-bottom: 1rem; }
.mb-4 { margin-bottom: 1.5rem; }
.mt-2 { margin-top: 0.5rem; }
.mt-3 { margin-top: 1rem; }
.p-3 { padding: 1rem; }
.p-4 { padding: 1.5rem; }
.pb-1 { padding-bottom: 0.25rem;}
.m-0 { margin: 0; }
.border { border: 1px solid #eaeaea; }
.rounded { border-radius: 8px; }
.border-left-success { border-left: 4px solid #17bb84 !important; }
.d-flex { display: flex; }
.justify-content-between { justify-content: space-between; }
.text-sm { font-size: 0.85rem; }
.text-dark { color: #202124; }
</style>
<?php require_once '../views/layouts/footer.php'; ?>
