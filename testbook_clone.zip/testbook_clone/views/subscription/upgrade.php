<?php require_once '../views/layouts/header.php'; ?>

<div class="container" style="padding: 40px 0; max-width: 1000px; text-align: center;">

    <?php if(isset($_GET['access']) && $_GET['access'] === 'denied'): ?>
        <div style="background: #ffebee; color: #c62828; padding: 15px; border-radius: 6px; margin-bottom: 30px; border: 1px solid #ef9a9a;">
            <strong>Premium Access Required!</strong> To start this mock test, you need an active Testbook Pro subscription. Upgrade below.
        </div>
    <?php endif; ?>

    <h1 style="font-size: 36px; margin-bottom: 10px;">Upgrade to Testbook Elite</h1>
    <p style="font-size: 18px; color: #666; margin-bottom: 40px;">Unlock all premium mock tests, detailed analytics, and ad-free experience.</p>

    <div style="display: flex; gap: 30px; justify-content: center; flex-wrap: wrap;">
        
        <!-- FREE TIER (Current) -->
        <div style="flex: 1; min-width: 250px; background: white; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); padding: 30px 20px; border: 1px solid #eee; display: flex; flex-direction: column;">
            <h3 style="margin-top: 0; color: #333;">Free Forever</h3>
            <h2 style="font-size: 40px; margin: 10px 0;">₹0<span style="font-size: 14px; color: #888;">/mo</span></h2>
            <ul style="list-style: none; padding: 0; margin: 20px 0; flex: 1; text-align: left; opacity: 0.8;">
                <li style="margin-bottom: 10px;">&#10004; Access to Free Tests</li>
                <li style="margin-bottom: 10px;">&#10004; Basic Question Analytics</li>
                <li style="margin-bottom: 10px; color: #aaa;">&#10008; Premium Mock Tests</li>
                <li style="margin-bottom: 10px; color: #aaa;">&#10008; Ad-free Experience</li>
                <li style="margin-bottom: 10px; color: #aaa;">&#10008; Priority Support</li>
            </ul>
            <div style="margin-top: auto;">
                <?php if($data['current_status'] === 'free'): ?>
                    <button disabled style="width: 100%; padding: 12px; background: #eee; color: #666; border: none; border-radius: 4px; font-weight: bold;">Current Plan</button>
                <?php else: ?>
                    <button disabled style="width: 100%; padding: 12px; background: #eee; color: #666; border: none; border-radius: 4px; font-weight: bold;">Included</button>
                <?php endif; ?>
            </div>
        </div>

        <!-- PREMIUM TIERS -->
        <?php foreach($data['plans'] as $idx => $plan): ?>
        <div style="flex: 1; min-width: 280px; background: white; border-radius: 8px; box-shadow: 0 8px 15px rgba(0,0,0,0.1); padding: 30px 20px; border: 2px solid <?php echo $idx === 1 ? '#007bff' : '#ddd'; ?>; display: flex; flex-direction: column; transform: <?php echo $idx === 1 ? 'scale(1.05)' : 'none'; ?>;">
            <?php if($idx === 1): ?>
                <div style="background: #007bff; color: white; padding: 5px; font-size: 12px; font-weight: bold; border-radius: 4px; position: absolute; top: -12px; left: 50%; transform: translateX(-50%);">MOST POPULAR</div>
            <?php endif; ?>
            <h3 style="margin-top: 0; color: #007bff;"><?php echo htmlspecialchars($plan['name']); ?></h3>
            <h2 style="font-size: 40px; margin: 10px 0; color: #333;">₹<?php echo $plan['price']; ?></h2>
            <ul style="list-style: none; padding: 0; margin: 20px 0; flex: 1; text-align: left;">
                <?php foreach($plan['features'] as $feature): ?>
                    <li style="margin-bottom: 10px; font-weight: 500;">
                        <span style="color: #28a745; margin-right: 5px;">&#10004;</span> <?php echo htmlspecialchars($feature); ?>
                    </li>
                <?php endforeach; ?>
            </ul>
            <div style="margin-top: auto;">
                <?php if($data['current_status'] === 'premium'): ?>
                    <button disabled style="width: 100%; padding: 12px; background: #d4edda; color: #155724; border: 1px solid #c3e6cb; border-radius: 4px; font-weight: bold;">You are Premium</button>
                <?php else: ?>
                    <a href="<?php echo APP_URL; ?>/subscription/checkout/<?php echo $plan['id']; ?>" class="btn btn-primary" style="display: block; width: 100%; padding: 12px; box-sizing: border-box; text-decoration: none;">Buy Pass</a>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>

    </div>
</div>

<?php require_once '../views/layouts/footer.php'; ?>
