<?php require_once '../views/layouts/header.php'; ?>

<div class="container" style="padding: 40px 0; max-width: 500px;">
    
    <div style="text-align: center; margin-bottom: 30px;">
        <h2>Secure Checkout</h2>
        <p style="color: #666;">You are upgrading to <strong><?php echo htmlspecialchars($data['plan']['name']); ?></strong></p>
    </div>

    <?php if(isset($data['error'])): ?>
        <div style="background: #ffebee; color: #c62828; padding: 15px; border-radius: 6px; margin-bottom: 20px; border: 1px solid #ef9a9a;">
            <?php echo htmlspecialchars($data['error']); ?>
        </div>
    <?php endif; ?>

    <div style="background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.1);">
        
        <div style="display: flex; justify-content: space-between; border-bottom: 1px solid #eee; padding-bottom: 15px; margin-bottom: 20px;">
            <span style="font-size: 18px; color: #555;">Order Total:</span>
            <span style="font-size: 24px; font-weight: bold; color: #333;">₹<?php echo htmlspecialchars($data['plan']['price']); ?></span>
        </div>

        <form action="<?php echo APP_URL; ?>/subscription/checkout/<?php echo $data['plan']['id']; ?>" method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
            
            <div style="margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 5px; font-weight: 500; font-size: 14px;">Mock Card Number (Demo)</label>
                <input type="text" placeholder="4111 1111 1111 1111" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; letter-spacing: 2px;">
            </div>

            <div style="display: flex; gap: 15px; margin-bottom: 20px;">
                <div style="flex: 1;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 500; font-size: 14px;">Expiry Date</label>
                    <input type="text" placeholder="MM/YY" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box;">
                </div>
                <div style="flex: 1;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 500; font-size: 14px;">CVV</label>
                    <input type="text" placeholder="123" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box;">
                </div>
            </div>

            <div style="background: #f8f9fa; padding: 10px; border-radius: 4px; font-size: 12px; color: #666; margin-bottom: 20px; text-align: center;">
                <span style="color: #28a745; font-weight: bold;">&#10004; Safe & Secure SSL Payment</span><br>
                (This is a mock system. Any data entered will approve the transaction instantly)
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 15px; font-size: 18px;">Pay ₹<?php echo htmlspecialchars($data['plan']['price']); ?></button>
            <div style="text-align: center; margin-top: 15px;">
                <a href="<?php echo APP_URL; ?>/subscription/plans" style="color: #666; text-decoration: none; font-size: 13px;">Cancel and go back</a>
            </div>
        </form>

    </div>
</div>

<?php require_once '../views/layouts/footer.php'; ?>
