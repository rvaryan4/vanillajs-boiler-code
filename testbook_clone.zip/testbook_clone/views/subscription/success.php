<?php require_once '../views/layouts/header.php'; ?>

<div class="container" style="padding: 60px 0; max-width: 600px; text-align: center;">

    <div style="background: white; padding: 40px 30px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.1);">
        <div style="width: 80px; height: 80px; background: #d4edda; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px auto;">
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#28a745" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="20 6 9 17 4 12"></polyline>
            </svg>
        </div>
        
        <h2 style="color: #28a745; margin-bottom: 10px;">Payment Successful!</h2>
        <p style="font-size: 18px; color: #333; margin-bottom: 5px;">Welcome to <strong>Testbook Elite</strong>.</p>
        <p style="color: #666; margin-bottom: 30px;">Your transaction ID is: <strong style="color: #333;"><?php echo htmlspecialchars($data['txn']); ?></strong></p>

        <p style="margin-bottom: 25px;">You now have full, unrestricted access to all Premium Mock Tests and analytical features across the platform.</p>

        <a href="<?php echo APP_URL; ?>/dashboard" class="btn btn-primary" style="padding: 12px 30px;">Go to Dashboard</a>
    </div>

</div>

<?php require_once '../views/layouts/footer.php'; ?>
