<?php require_once '../views/layouts/header.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<div class="container" style="padding: 40px 0; max-width: 1200px;">
    
    <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 30px;">
        <div>
            <h1 style="margin: 0; font-size: 28px;">Performance Analytics</h1>
            <p style="color: #666; margin: 5px 0 0 0;">Track your accuracy, speed, and weak areas in real-time.</p>
        </div>
        <div>
            <?php if($data['subscription'] === 'free'): ?>
                <a href="<?php echo APP_URL; ?>/subscription/plans" class="btn btn-primary" style="background: #f57f17; border-color: #f57f17; font-weight: bold;">&#9733; Go Premium</a>
            <?php else: ?>
                <span style="background: #28a745; color: white; padding: 5px 10px; border-radius: 4px; font-weight: bold; font-size: 14px;">PRO MEMBER</span>
            <?php endif; ?>
        </div>
    </div>

    <!-- STATS CARDS -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 40px;">
        <div style="background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); text-align: center; border-bottom: 4px solid #007bff;">
            <div style="font-size: 32px; font-weight: bold; color: #333;"><?php echo $data['stats']['overall_accuracy']; ?>%</div>
            <div style="color: #666; font-size: 14px; text-transform: uppercase; letter-spacing: 1px;">Overall Accuracy</div>
        </div>
        <div style="background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); text-align: center; border-bottom: 4px solid #28a745;">
            <div style="font-size: 32px; font-weight: bold; color: #333;"><?php echo $data['stats']['total_tests']; ?></div>
            <div style="color: #666; font-size: 14px; text-transform: uppercase; letter-spacing: 1px;">Mock Tests Attempted</div>
        </div>
        <div style="background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); text-align: center; border-bottom: 4px solid #f57f17;">
            <div style="font-size: 32px; font-weight: bold; color: #333;"><?php echo $data['stats']['avg_time_per_question']; ?>s</div>
            <div style="color: #666; font-size: 14px; text-transform: uppercase; letter-spacing: 1px;">Avg Time / Question</div>
        </div>
        <div style="background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); text-align: center; border-bottom: 4px solid #6c757d;">
            <div style="font-size: 32px; font-weight: bold; color: #333;"><?php echo $data['stats']['total_questions_attempted']; ?></div>
            <div style="color: #666; font-size: 14px; text-transform: uppercase; letter-spacing: 1px;">Questions Solved</div>
        </div>
    </div>

    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 30px; margin-bottom: 40px;">
        <!-- CHART -->
        <div style="background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.05);">
            <h3 style="margin-top: 0; margin-bottom: 20px;">Accuracy Trend (Last 10 Tests)</h3>
            <canvas id="accuracyChart" height="100"></canvas>
        </div>

        <!-- WEAK TOPICS -->
        <div style="background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.05);">
            <h3 style="margin-top: 0; margin-bottom: 20px; color: #dc3545;">Weakest Areas</h3>
            <?php if(empty($data['weak_topics'])): ?>
                <p style="color: #666; font-size: 14px;">Take more tests to identify weak areas.</p>
            <?php else: ?>
                <ul style="list-style: none; padding: 0; margin: 0;">
                    <?php foreach(array_slice($data['weak_topics'], 0, 5) as $topic): ?>
                        <li style="margin-bottom: 15px;">
                            <div style="display: flex; justify-content: space-between; margin-bottom: 5px; font-size: 14px;">
                                <strong><?php echo $topic['difficulty']; ?> Questions</strong>
                                <span style="color: <?php echo $topic['accuracy'] < 50 ? '#dc3545' : '#f57f17'; ?>; font-weight: bold;">
                                    <?php echo $topic['accuracy']; ?>%
                                </span>
                            </div>
                            <div style="width: 100%; background: #eee; height: 6px; border-radius: 3px; overflow: hidden;">
                                <div style="width: <?php echo $topic['accuracy']; ?>%; background: <?php echo $topic['accuracy'] < 50 ? '#dc3545' : '#f57f17'; ?>; height: 100%;"></div>
                            </div>
                            <div style="font-size: 11px; color: #888; margin-top: 3px;"><?php echo $topic['attempts']; ?> Attempts</div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>

    <!-- TEST HISTORY TABLE -->
    <div style="background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.05);">
        <h3 style="margin-top: 0; margin-bottom: 20px;">Recent Test History</h3>
        
        <?php if(empty($data['history'])): ?>
            <p style="color: #666;">No tests completed yet. Start your preparation!</p>
        <?php else: ?>
            <div style="overflow-x: auto;">
                <table style="width: 100%; border-collapse: collapse; min-width: 700px;">
                    <thead>
                        <tr style="border-bottom: 2px solid #eee; text-align: left; background: #f8f9fa;">
                            <th style="padding: 12px; font-size: 14px; color: #555;">Date</th>
                            <th style="padding: 12px; font-size: 14px; color: #555;">Test Name</th>
                            <th style="padding: 12px; font-size: 14px; color: #555; text-align: center;">Attempted</th>
                            <th style="padding: 12px; font-size: 14px; color: #555; text-align: center;">Accuracy</th>
                            <th style="padding: 12px; font-size: 14px; color: #555; text-align: center;">Time Taken</th>
                            <th style="padding: 12px; font-size: 14px; color: #555; text-align: right;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($data['history'] as $h): ?>
                            <tr style="border-bottom: 1px solid #eee;">
                                <td style="padding: 12px; font-size: 14px;"><?php echo date('d M Y, h:i A', strtotime($h['end_time'])); ?></td>
                                <td style="padding: 12px; font-size: 14px; font-weight: 500;">
                                    <?php echo htmlspecialchars($h['quiz_title'] ?? 'Mock Test #' . $h['quiz_slug']); ?>
                                </td>
                                <td style="padding: 12px; font-size: 14px; text-align: center;"><?php echo $h['total_attempted']; ?></td>
                                <td style="padding: 12px; font-size: 14px; text-align: center;">
                                    <span style="font-weight: bold; color: <?php echo $h['accuracy'] >= 75 ? '#28a745' : ($h['accuracy'] >= 40 ? '#f57f17' : '#dc3545'); ?>;">
                                        <?php echo $h['accuracy']; ?>%
                                    </span>
                                </td>
                                <td style="padding: 12px; font-size: 14px; text-align: center;">
                                    <?php echo floor($h['time_taken_seconds'] / 60); ?>m <?php echo $h['time_taken_seconds'] % 60; ?>s
                                </td>
                                <td style="padding: 12px; text-align: right;">
                                    <a href="<?php echo APP_URL; ?>/<?php echo APP_LANG; ?>/test/<?php echo $h['quiz_slug']; ?>" style="font-size: 13px; color: #007bff; text-decoration: none;">Reattempt</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('accuracyChart');
    if(!ctx) return;

    const labels = <?php echo $data['chart_labels']; ?>;
    const dataPoints = <?php echo $data['chart_data']; ?>;

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Accuracy %',
                data: dataPoints,
                borderColor: '#007bff',
                backgroundColor: 'rgba(0, 123, 255, 0.1)',
                borderWidth: 2,
                pointBackgroundColor: '#007bff',
                pointRadius: 4,
                fill: true,
                tension: 0.3
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: { callback: function(value) { return value + "%" } }
                }
            },
            plugins: {
                legend: { display: false }
            }
        }
    });
});
</script>

<?php require_once '../views/layouts/footer.php'; ?>
