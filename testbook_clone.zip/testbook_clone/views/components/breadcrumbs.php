<?php if (isset($data['breadcrumbs']) && !empty($data['breadcrumbs'])): ?>
<nav aria-label="breadcrumb" style="margin-bottom: 20px; font-size: 14px; background: #f8f9fa; padding: 10px 15px; border-radius: 4px;">
    <ol style="list-style: none; padding: 0; margin: 0; display: flex; flex-wrap: wrap;">
        <?php foreach ($data['breadcrumbs'] as $idx => $crumb): ?>
            <li class="breadcrumb-item" <?php echo ($idx === count($data['breadcrumbs']) - 1) ? 'aria-current="page"' : ''; ?> style="display: flex; align-items: center;">
                <?php if ($idx < count($data['breadcrumbs']) - 1): ?>
                    <a href="<?php echo $crumb['url']; ?>" style="color: #007bff; text-decoration: none;"><?php echo htmlspecialchars($crumb['name']); ?></a>
                    <span style="margin: 0 10px; color: #6c757d;">/</span>
                <?php else: ?>
                    <span style="color: #6c757d; font-weight: 500;"><?php echo htmlspecialchars($crumb['name']); ?></span>
                <?php endif; ?>
            </li>
        <?php endforeach; ?>
    </ol>
</nav>

<!-- JSON-LD Structured Data for Breadcrumbs (SEO Boost) -->
<script type="application/ld+json">
{
  "@context": "https://schema.org/", 
  "@type": "BreadcrumbList", 
  "itemListElement": [
    <?php 
    $total = count($data['breadcrumbs']);
    foreach ($data['breadcrumbs'] as $idx => $crumb): 
    ?>
    {
      "@type": "ListItem", 
      "position": <?php echo $idx + 1; ?>, 
      "name": "<?php echo htmlspecialchars(str_replace('"', '\"', $crumb['name'])); ?>",
      "item": "<?php echo $crumb['url']; ?>"  
    }<?php echo ($idx < $total - 1) ? ',' : ''; ?>
    <?php endforeach; ?>
  ]
}
</script>
<?php endif; ?>
