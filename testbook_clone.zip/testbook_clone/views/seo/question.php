<?php require_once '../views/layouts/header.php'; ?>

<div class="container" style="padding: 40px 0; max-width: 900px;">
    <?php require_once '../views/components/breadcrumbs.php'; ?>

    <div style="background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
        <h1 style="font-size: 20px; font-weight: 500; color: #444; margin-bottom: 30px; line-height: 1.6;">
            <?php echo nl2br(htmlspecialchars($data['question']['question_text'])); ?>
        </h1>
        
        <div style="background: #f8f9fa; padding: 20px; border-radius: 6px; margin-bottom: 30px; border-left: 4px solid #2196F3;">
            <p style="margin: 0; color: #555;">
                <strong>Explanation:</strong><br><br>
                <?php echo nl2br(htmlspecialchars($data['question']['explanation'] ?? 'A detailed step-by-step solution for this problem has not been published directly. Try attempting the mock test series to review this question dynamically.')); ?>
            </p>
        </div>

        <p style="font-size: 14px; color: #777;">
            Want to test yourself in a real timed environment?
            <a href="<?php echo APP_URL; ?>/<?php echo APP_LANG; ?>/test/<?php echo $data['question']['quiz_slug']; ?>" style="color: #007bff; font-weight: bold;">Access the full Mock Test Here</a>.
        </p>
    </div>
</div>

<?php require_once '../views/layouts/footer.php'; ?>
