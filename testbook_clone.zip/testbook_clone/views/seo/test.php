<?php require_once '../views/layouts/header.php'; ?>

<div class="container" style="padding: 40px 0; max-width: 900px;">
    <?php require_once '../views/components/breadcrumbs.php'; ?>

    <div style="background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
        <h1><?php echo htmlspecialchars($data['quiz']['title']); ?></h1>
        
        <div style="display: flex; gap: 15px; margin: 15px 0;">
            <span style="background: #e1f5fe; padding: 5px 10px; border-radius: 4px; font-size: 14px; color: #0277bd;">Time Limit: <?php echo $data['quiz']['time_limit_minutes']; ?> Mins</span>
            <span style="background: #e1f5fe; padding: 5px 10px; border-radius: 4px; font-size: 14px; color: #0277bd;">Total Marks: <?php echo $data['quiz']['total_marks']; ?></span>
            <?php if($data['quiz']['is_premium']): ?>
                <span style="background: #ffecb3; padding: 5px 10px; border-radius: 4px; font-size: 14px; color: #f57f17; font-weight: bold;">PREMIUM MOCK TEST</span>
            <?php else: ?>
                <span style="background: #e8f5e9; padding: 5px 10px; border-radius: 4px; font-size: 14px; color: #2e7d32; font-weight: bold;">FREE TEST</span>
            <?php endif; ?>
        </div>

        <p style="font-size: 16px; line-height: 1.6; color: #333; margin-top: 20px;">
            <?php echo htmlspecialchars($data['quiz']['description'] ?? 'This is an official mock test. Use this to practice and improve your score.'); ?>
        </p>

        <div style="margin-top: 30px;">
            <a href="<?php echo APP_URL; ?>/quiz/instructions/<?php echo $data['quiz']['id']; ?>" class="btn btn-primary" style="padding: 12px 30px; font-size: 18px;">Start Mock Test Now</a>
        </div>
    </div>
</div>

<?php require_once '../views/layouts/footer.php'; ?>
