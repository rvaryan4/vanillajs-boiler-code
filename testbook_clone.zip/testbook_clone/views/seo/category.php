<?php require_once '../views/layouts/header.php'; ?>

<div class="container" style="padding: 40px 0; max-width: 1000px;">
    <?php require_once '../views/components/breadcrumbs.php'; ?>

    <div style="text-align: center; margin-bottom: 40px;">
        <h1 style="font-size: 32px; margin-bottom: 15px;"><?php echo htmlspecialchars($data['category']['name']); ?> Exam Preparation</h1>
        <p style="font-size: 18px; color: #555; max-width: 700px; margin: 0 auto;">
            <?php echo htmlspecialchars($data['category']['description'] ?? 'Explore the best mock tests, quizzes, and preparation material for ' . $data['category']['name'] . '.'); ?>
        </p>
    </div>

    <h2 style="margin-bottom: 20px;">Latest Mock Tests Series</h2>
    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px;">
        <?php if(!empty($data['quizzes'])): ?>
            <?php foreach($data['quizzes'] as $q): ?>
                <div style="background: white; border: 1px solid #ddd; border-radius: 8px; padding: 20px; transition: transform 0.2s, box-shadow 0.2s;">
                    <h3 style="margin-top: 0; margin-bottom: 10px; font-size: 18px;">
                        <a href="<?php echo APP_URL; ?>/<?php echo APP_LANG; ?>/test/<?php echo $q['slug']; ?>" style="color: #333; text-decoration: none;">
                            <?php echo htmlspecialchars($q['title']); ?>
                        </a>
                    </h3>
                    <p style="font-size: 13px; color: #666; margin-bottom: 15px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                        <?php echo htmlspecialchars($q['description'] ?? 'Take this highly engaging practice test to boost your scores.'); ?>
                    </p>
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span style="font-size: 12px; font-weight: bold; padding: 4px 8px; border-radius: 4px; background: #f0f2f5;">
                            <?php echo $q['time_limit_minutes']; ?> Mins | <?php echo $q['total_marks']; ?> Marks
                        </span>
                        <?php if($q['is_premium']): ?>
                            <span style="font-size: 12px; color: #f57f17; font-weight: bold;">&#9733; PREMIUM</span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No tests are published in this category yet. Check back soon!</p>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../views/layouts/footer.php'; ?>
