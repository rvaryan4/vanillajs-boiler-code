    </main>
    <footer class="footer">
        <div class="container text-center">
            <p>&copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?>. All rights reserved.</p>
        </div>
    </footer>
    <script src="<?php echo APP_URL; ?>/js/main.js"></script>
</body>
</html>
