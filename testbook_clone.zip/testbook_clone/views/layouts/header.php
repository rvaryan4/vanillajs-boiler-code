<!DOCTYPE html>
<html lang="<?php echo $_SESSION['lang'] ?? 'en'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($data['meta_title']) ? e($data['meta_title']) : APP_NAME; ?></title>
    
    <?php if(isset($data['meta_description'])): ?>
    <meta name="description" content="<?php echo e($data['meta_description']); ?>">
    <?php endif; ?>
    
    <?php if(isset($data['canonical_url'])): ?>
    <link rel="canonical" href="<?php echo e($data['canonical_url']); ?>">
    <?php endif; ?>

    <!-- Global Security Header for AJAX -->
    <meta name="csrf-token" content="<?php echo generateCsrfToken(); ?>">

    <link rel="stylesheet" href="<?php echo APP_URL; ?>/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <script src="<?php echo APP_URL; ?>/js/app.js" defer></script>
</head>
<body>

    <!-- Unified Global XHR Loading Spinner -->
    <div id="global-loader" class="loader-overlay hidden">
        <div class="loader-spinner"></div>
    </div>
    <nav class="navbar">
        <div class="container nav-content">
            <a href="<?php echo APP_URL; ?>" class="brand"><?php echo APP_NAME; ?></a>
            <div class="nav-links" style="display: flex; align-items: center;">
                <?php
                if (!class_exists('LanguageModel')) {
                    require_once dirname(__DIR__) . '/../models/LanguageModel.php';
                }
                $langModel = new LanguageModel();
                $languages = $langModel->getActiveLanguages();
                $currentLang = defined('APP_LANG') ? APP_LANG : 'en';
                ?>
                <select class="lang-switcher" onchange="switchLanguage(this.value)" style="margin-right: 20px; padding: 5px; border-radius: 4px; border: 1px solid #ccc; background: white;">
                    <?php foreach ($languages as $lg): ?>
                        <option value="<?php echo htmlspecialchars($lg['code']); ?>" <?php echo $currentLang === $lg['code'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($lg['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <script>
                function switchLanguage(langCode) {
                    let path = window.location.pathname;
                    let parts = path.split('/').filter(p => p);
                    
                    // If first segment is 2 chars, replace it. Otherwise, prepend it.
                    let baseUrlPath = new URL("<?php echo APP_URL; ?>").pathname.replace(/^\/|\/$/g, '');
                    let appPartsCount = baseUrlPath ? baseUrlPath.split('/').length : 0;
                    
                    let routeParts = parts.slice(appPartsCount);
                    if (routeParts.length > 0 && routeParts[0].length === 2) {
                        routeParts[0] = langCode;
                    } else {
                        routeParts.unshift(langCode);
                    }
                    
                    let newPath = (baseUrlPath ? '/' + baseUrlPath : '') + '/' + routeParts.join('/');
                    window.location.href = window.location.origin + newPath + window.location.search;
                }
                </script>
                <?php if(isset($_SESSION['user_id'])): ?>
                    <a href="<?php echo APP_URL; ?>/dashboard">Dashboard</a>
                    <a href="<?php echo APP_URL; ?>/auth/logout" class="btn btn-outline" style="margin-left: 20px;">Logout</a>
                <?php else: ?>
                    <a href="<?php echo APP_URL; ?>/auth/login" class="btn btn-outline">Login</a>
                    <a href="<?php echo APP_URL; ?>/auth/register" class="btn btn-primary" style="margin-left: 10px;">Sign Up</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    <main class="main-content">
