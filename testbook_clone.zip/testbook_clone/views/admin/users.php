<?php require_once '../views/layouts/header.php'; ?>

<div style="display: flex; max-width: 1200px; margin: 0 auto;">
    <div style="width: 250px; background: #fff; padding: 20px; border-right: 1px solid #ddd; min-height: calc(100vh - 60px);">
        <h3>Admin Menu</h3>
        <a href="<?php echo APP_URL; ?>/admin/dashboard" style="display: block; padding: 10px; color: #333; text-decoration: none;">Dashboard</a>
        <a href="<?php echo APP_URL; ?>/admin/users" style="display: block; padding: 10px; color: #007bff; font-weight: bold;">Manage Users</a>
        <a href="<?php echo APP_URL; ?>/admin/categories" style="display: block; padding: 10px; color: #333; text-decoration: none;">Manage Categories</a>
        <a href="<?php echo APP_URL; ?>/admin/quizzes" style="display: block; padding: 10px; color: #333; text-decoration: none;">Manage Quizzes</a>
    </div>

    <div style="flex: 1; padding: 30px;">
        <h2>Manage Users</h2>

        <?php if(isset($_GET['success'])): ?>
            <div style="padding: 10px; background: #e6ffed; border: 1px solid #b3f0c2; margin-bottom: 15px;">Status updated successfully.</div>
        <?php endif; ?>

        <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
            <table style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr style="border-bottom: 2px solid #ddd; text-align: left;">
                        <th style="padding: 10px;">ID</th>
                        <th style="padding: 10px;">Name</th>
                        <th style="padding: 10px;">Email</th>
                        <th style="padding: 10px;">Role</th>
                        <th style="padding: 10px;">Subscription</th>
                        <th style="padding: 10px;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($data['users'])): ?>
                        <?php foreach($data['users'] as $user): ?>
                        <tr style="border-bottom: 1px solid #eee;">
                            <td style="padding: 10px;"><?php echo $user['id']; ?></td>
                            <td style="padding: 10px;"><?php echo htmlspecialchars($user['name']); ?></td>
                            <td style="padding: 10px;"><?php echo htmlspecialchars($user['email']); ?></td>
                            <td style="padding: 10px;"><?php echo htmlspecialchars($user['role']); ?></td>
                            <td style="padding: 10px;">
                                <span style="padding: 4px 8px; border-radius: 4px; font-size: 12px; background: <?php echo $user['subscription_status'] === 'premium' ? '#e1f5fe' : '#f5f5f5'; ?>;">
                                    <?php echo strtoupper($user['subscription_status']); ?>
                                </span>
                            </td>
                            <td style="padding: 10px;">
                                <form action="<?php echo APP_URL; ?>/admin/users" method="POST" style="display: inline;">
                                    <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                    <input type="hidden" name="subscription_status" value="<?php echo $user['subscription_status'] === 'free' ? 'premium' : 'free'; ?>">
                                    <button type="submit" class="btn btn-action" style="padding: 5px 10px; cursor: pointer;">
                                        Make <?php echo $user['subscription_status'] === 'free' ? 'Premium' : 'Free'; ?>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="6" style="padding: 15px; text-align: center;">No users found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../views/layouts/footer.php'; ?>
