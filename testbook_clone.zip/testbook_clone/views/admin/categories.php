<?php require_once '../views/layouts/header.php'; ?>

<div style="display: flex; max-width: 1200px; margin: 0 auto;">
    <div style="width: 250px; background: #fff; padding: 20px; border-right: 1px solid #ddd; min-height: calc(100vh - 60px);">
        <h3>Admin Menu</h3>
        <a href="<?php echo APP_URL; ?>/admin/dashboard" style="display: block; padding: 10px; color: #333; text-decoration: none;">Dashboard</a>
        <a href="<?php echo APP_URL; ?>/admin/users" style="display: block; padding: 10px; color: #333; text-decoration: none;">Manage Users</a>
        <a href="<?php echo APP_URL; ?>/admin/categories" style="display: block; padding: 10px; color: #007bff; font-weight: bold;">Manage Categories</a>
        <a href="<?php echo APP_URL; ?>/admin/quizzes" style="display: block; padding: 10px; color: #333; text-decoration: none;">Manage Quizzes</a>
    </div>

    <div style="flex: 1; padding: 30px;">
        <h2>Manage Categories</h2>

        <?php if(isset($_GET['success'])): ?>
            <div style="padding: 10px; background: #e6ffed; border: 1px solid #b3f0c2; margin-bottom: 15px;">Category created successfully.</div>
        <?php endif; ?>

        <div style="display: flex; gap: 20px;">
            <!-- Create Form -->
            <div style="flex: 1; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                <h4>Add New Category</h4>
                <form action="<?php echo APP_URL; ?>/admin/categories" method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
                    
                    <div style="margin-bottom: 15px;">
                        <label>URL Slug (e.g. upsc-exams)</label>
                        <input type="text" name="slug" required style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                    </div>
                    
                    <div style="margin-bottom: 15px;">
                        <label>Parent Category (Optional)</label>
                        <select name="parent_id" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                            <option value="">-- None --</option>
                            <?php foreach($data['categories'] as $cat): ?>
                                <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['default_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <hr style="margin: 15px 0;">
                    <h5>English Content</h5>
                    <div style="margin-bottom: 15px;">
                        <label>Category Name (EN)</label>
                        <input type="text" name="en_name" required style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                    </div>
                    <div style="margin-bottom: 15px;">
                        <label>Description (EN)</label>
                        <textarea name="en_desc" rows="3" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;"></textarea>
                    </div>

                    <hr style="margin: 15px 0;">
                    <h5>Hindi Content (Optional)</h5>
                    <div style="margin-bottom: 15px;">
                        <label>Category Name (HI)</label>
                        <input type="text" name="hi_name" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                    </div>
                    <div style="margin-bottom: 15px;">
                        <label>Description (HI)</label>
                        <textarea name="hi_desc" rows="3" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;"></textarea>
                    </div>

                    <button type="submit" style="padding: 10px 20px; background: #28a745; color: white; border: none; border-radius: 4px; cursor: pointer;">Add Category</button>
                </form>
            </div>

            <!-- List View -->
            <div style="flex: 1; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                <h4>Active Categories</h4>
                <ul style="list-style: none; padding: 0;">
                    <?php if(!empty($data['categories'])): ?>
                        <?php foreach($data['categories'] as $cat): ?>
                            <li style="padding: 10px; border-bottom: 1px solid #eee;">
                                <strong><?php echo htmlspecialchars($cat['default_name']); ?></strong><br>
                                <span style="font-size: 12px; color: #666;">/<?php echo htmlspecialchars($cat['slug']); ?> | ID: <?php echo $cat['id']; ?></span>
                            </li>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <li>No categories found.</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php require_once '../views/layouts/footer.php'; ?>
