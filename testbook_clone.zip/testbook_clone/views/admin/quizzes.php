<?php require_once '../views/layouts/header.php'; ?>

<div style="display: flex; max-width: 1200px; margin: 0 auto;">
    <div style="width: 250px; background: #fff; padding: 20px; border-right: 1px solid #ddd; min-height: calc(100vh - 60px);">
        <h3>Admin Menu</h3>
        <a href="<?php echo APP_URL; ?>/admin/dashboard" style="display: block; padding: 10px; color: #333; text-decoration: none;">Dashboard</a>
        <a href="<?php echo APP_URL; ?>/admin/users" style="display: block; padding: 10px; color: #333; text-decoration: none;">Manage Users</a>
        <a href="<?php echo APP_URL; ?>/admin/categories" style="display: block; padding: 10px; color: #333; text-decoration: none;">Manage Categories</a>
        <a href="<?php echo APP_URL; ?>/admin/quizzes" style="display: block; padding: 10px; color: #007bff; font-weight: bold;">Manage Quizzes</a>
    </div>

    <div style="flex: 1; padding: 30px;">
        <h2>Manage Quizzes (Test Series)</h2>

        <?php if(isset($_GET['success'])): ?>
            <div style="padding: 10px; background: #e6ffed; border: 1px solid #b3f0c2; margin-bottom: 15px;">Quiz created successfully.</div>
        <?php endif; ?>

        <div style="display: flex; gap: 20px;">
            <!-- Create Form -->
            <div style="flex: 1; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                <h4>Create New Quiz</h4>
                <form action="<?php echo APP_URL; ?>/admin/quizzes" method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
                    
                    <div style="margin-bottom: 15px;">
                        <label>Category</label>
                        <select name="category_id" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;" required>
                            <option value="">-- Select Category --</option>
                            <?php foreach($data['categories'] as $cat): ?>
                                <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['default_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div style="margin-bottom: 15px;">
                        <label>URL Slug (e.g. mock-test-1)</label>
                        <input type="text" name="slug" required style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                    </div>

                    <div style="display: flex; gap: 10px; margin-bottom: 15px;">
                        <div style="flex: 1;">
                            <label>Time Limit (Mins)</label>
                            <input type="number" name="time_limit_minutes" value="60" required style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                        </div>
                        <div style="flex: 1;">
                            <label>Total Marks</label>
                            <input type="number" name="total_marks" value="100" required style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                        </div>
                        <div style="flex: 1;">
                            <label>Passing Marks</label>
                            <input type="number" name="passing_marks" value="40" required style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                        </div>
                    </div>

                    <div style="display: flex; gap: 10px; margin-bottom: 15px;">
                        <div style="flex: 1;">
                            <label>Status</label>
                            <select name="status" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                                <option value="draft">Draft</option>
                                <option value="published">Published</option>
                            </select>
                        </div>
                        <div style="flex: 1;">
                            <label>Is Premium?</label>
                            <select name="is_premium" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                                <option value="0">No (Free)</option>
                                <option value="1">Yes (Premium)</option>
                            </select>
                        </div>
                    </div>

                    <hr style="margin: 15px 0;">
                    <h5>English Content</h5>
                    <div style="margin-bottom: 15px;">
                        <label>Quiz Title (EN)</label>
                        <input type="text" name="en_title" required style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                    </div>
                    <div style="margin-bottom: 15px;">
                        <label>Description (EN)</label>
                        <textarea name="en_desc" rows="3" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;"></textarea>
                    </div>

                    <hr style="margin: 15px 0;">
                    <h5>Hindi Content (Optional)</h5>
                    <div style="margin-bottom: 15px;">
                        <label>Quiz Title (HI)</label>
                        <input type="text" name="hi_title" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                    </div>

                    <button type="submit" style="padding: 10px 20px; background: #28a745; color: white; border: none; border-radius: 4px; cursor: pointer;">Add Quiz</button>
                </form>
            </div>

            <!-- List View -->
            <div style="flex: 1; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                <h4>Active Quizzes</h4>
                <ul style="list-style: none; padding: 0;">
                    <?php if(!empty($data['quizzes'])): ?>
                        <?php foreach($data['quizzes'] as $q): ?>
                            <li style="padding: 15px; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; align-items: center;">
                                <div>
                                    <strong><?php echo htmlspecialchars($q['default_title']); ?></strong>
                                    <span style="font-size: 11px; padding: 2px 6px; background: #eee; border-radius: 4px; margin-left: 10px;"><?php echo strtoupper($q['status']); ?></span>
                                    <br>
                                    <span style="font-size: 12px; color: #666;"><?php echo $q['time_limit_minutes']; ?> Mins | <?php echo $q['total_marks']; ?> Marks</span>
                                </div>
                                <div>
                                    <a href="<?php echo APP_URL; ?>/admin/questions/<?php echo $q['id']; ?>" style="padding: 6px 12px; background: #007bff; color: white; border-radius: 4px; text-decoration: none; font-size: 13px;">Manage Questions</a>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <li>No quizzes found.</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php require_once '../views/layouts/footer.php'; ?>
