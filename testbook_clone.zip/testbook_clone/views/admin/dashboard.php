<?php require_once '../views/layouts/header.php'; ?>

<style>
.admin-sidebar { width: 250px; background: #fff; padding: 20px; border-right: 1px solid #ddd; min-height: calc(100vh - 60px); }
.admin-sidebar a { display: block; padding: 10px; color: #333; text-decoration: none; margin-bottom: 5px; border-radius: 4px; }
.admin-sidebar a:hover { background: #f0f2f5; color: #007bff; }
.admin-content { flex: 1; padding: 30px; }
.admin-container { display: flex; max-width: 1200px; margin: 0 auto; }
.card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); margin-bottom: 20px; }
</style>

<div class="admin-container">
    <div class="admin-sidebar">
        <h3>Admin Menu</h3>
        <a href="<?php echo APP_URL; ?>/admin/dashboard">Dashboard</a>
        <a href="<?php echo APP_URL; ?>/admin/users">Manage Users</a>
        <a href="<?php echo APP_URL; ?>/admin/categories">Manage Categories</a>
        <a href="<?php echo APP_URL; ?>/admin/quizzes">Manage Quizzes</a>
    </div>

    <div class="admin-content">
        <h2>Admin Dashboard</h2>
        <div class="card">
            <h4>Welcome, Admin!</h4>
            <p>Use the sidebar to navigate through the management tools.</p>
            <p><strong>Note:</strong> All creations here support localized translations (English/Hindi) natively, injecting directly into your normalized database tables.</p>
        </div>
    </div>
</div>

<?php require_once '../views/layouts/footer.php'; ?>
