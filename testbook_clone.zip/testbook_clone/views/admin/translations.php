<?php require_once '../views/layouts/header.php'; ?>

<div class="container" style="padding: 40px 0;">
    <h2>Admin - Manage Translations</h2>

    <?php if(isset($_GET['success'])): ?>
        <div style="padding: 15px; background: #e6ffed; border: 1px solid #b3f0c2; margin-bottom: 20px;">Translation saved successfully.</div>
    <?php endif; ?>

    <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); margin-top: 20px;">
        <h3>Add New Translation (Example)</h3>
        <p>This form allows you to insert or update translations dynamically.</p>
        
        <form action="<?php echo APP_URL; ?>/admintranslation/add" method="POST" style="margin-top: 20px; max-width: 500px;">
            <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
            <div style="margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 5px;">Language</label>
                <select name="language_id" style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;" required>
                    <option value="">-- Select Language --</option>
                    <?php foreach($data['languages'] as $lang): ?>
                        <option value="<?php echo $lang['id']; ?>"><?php echo $lang['name']; ?> (<?php echo $lang['code']; ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div style="margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 5px;">Translate Entity (Table)</label>
                <select name="table" style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;" required>
                    <option value="category_translations">Categories (category_translations)</option>
                    <option value="quiz_translations">Quizzes (quiz_translations)</option>
                    <option value="question_translations">Questions (question_translations)</option>
                </select>
            </div>

            <div style="margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 5px;">Entity Column Name</label>
                <input type="text" name="entity_col" placeholder="e.g. quiz_id" value="quiz_id" style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;" required>
            </div>

            <div style="margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 5px;">Entity ID</label>
                <input type="number" name="entity_id" placeholder="ID of the category, quiz, or question" style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;" required>
            </div>

            <div style="margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 5px;">Target Field</label>
                <input type="text" name="field" placeholder="e.g. title, question_text, name" value="title" style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;" required>
            </div>

            <div style="margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 5px;">Translated Text</label>
                <textarea name="text" rows="4" style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;" required></textarea>
            </div>

            <button type="submit" class="btn btn-primary" style="padding: 10px 20px; font-size: 16px;">Save Translation</button>
        </form>
    </div>
</div>

<?php require_once '../views/layouts/footer.php'; ?>
