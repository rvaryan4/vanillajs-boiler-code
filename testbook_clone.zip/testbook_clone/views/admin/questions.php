<?php require_once '../views/layouts/header.php'; ?>

<div style="display: flex; max-width: 1200px; margin: 0 auto;">
    <div style="width: 250px; background: #fff; padding: 20px; border-right: 1px solid #ddd; min-height: calc(100vh - 60px);">
        <h3>Admin Menu</h3>
        <a href="<?php echo APP_URL; ?>/admin/dashboard" style="display: block; padding: 10px; color: #333; text-decoration: none;">Dashboard</a>
        <a href="<?php echo APP_URL; ?>/admin/users" style="display: block; padding: 10px; color: #333; text-decoration: none;">Manage Users</a>
        <a href="<?php echo APP_URL; ?>/admin/categories" style="display: block; padding: 10px; color: #333; text-decoration: none;">Manage Categories</a>
        <a href="<?php echo APP_URL; ?>/admin/quizzes" style="display: block; padding: 10px; color: #007bff; font-weight: bold;">Manage Quizzes</a>
    </div>

    <div style="flex: 1; padding: 30px;">
        <h2><a href="<?php echo APP_URL; ?>/admin/quizzes" style="text-decoration: none; color: #007bff;">&larr;</a> Manage Questions (Quiz #<?php echo $data['quiz_id']; ?>)</h2>

        <?php if(isset($_GET['success'])): ?>
            <div style="padding: 10px; background: #e6ffed; border: 1px solid #b3f0c2; margin-bottom: 15px;">Question added successfully.</div>
        <?php endif; ?>

        <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); margin-bottom: 30px;">
            <h4>Add New MCQ Question</h4>
            <p>You can add English and Hindi side-by-side for instantaneous multilingual support.</p>
            <form action="<?php echo APP_URL; ?>/admin/questions/<?php echo $data['quiz_id']; ?>" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
                
                <div style="display: flex; gap: 15px; margin-bottom: 15px;">
                    <div style="flex: 1;">
                        <label>Question Type</label>
                        <select name="type" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                            <option value="multiple_choice">Multiple Choice (Single Answer)</option>
                        </select>
                    </div>
                    <div style="flex: 1;">
                        <label>Marks</label>
                        <input type="number" step="0.5" name="marks" value="1.0" required style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                    </div>
                    <div style="flex: 1;">
                        <label>Negative Marks</label>
                        <input type="number" step="0.25" name="negative_marks" value="0.25" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                    </div>
                    <div style="flex: 1;">
                        <label>Difficulty</label>
                        <select name="difficulty" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                            <option value="easy">Easy</option>
                            <option value="medium" selected>Medium</option>
                            <option value="hard">Hard</option>
                        </select>
                    </div>
                </div>

                <div style="display: flex; gap: 20px; margin-bottom: 20px;">
                    <div style="flex: 1;">
                        <label><strong>Question Text (EN) *</strong></label>
                        <textarea name="en_question_text" rows="3" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;"></textarea>
                    </div>
                    <div style="flex: 1;">
                        <label><strong>Question Text (HI)</strong></label>
                        <textarea name="hi_question_text" rows="3" style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;"></textarea>
                    </div>
                </div>

                <h5 style="margin-top: 0;">Options (Mark the radio button for the correct answer)</h5>
                
                <?php for($i = 0; $i < 4; $i++): ?>
                <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 10px; background: #f8f9fa; padding: 10px; border-radius: 4px;">
                    <div>
                        <input type="radio" name="correct_option" value="<?php echo $i; ?>" <?php echo $i === 0 ? 'required' : ''; ?> style="transform: scale(1.5);">
                    </div>
                    <div style="flex: 1;">
                        <input type="text" name="en_opt_<?php echo $i; ?>" placeholder="Option <?php echo $i+1; ?> (EN) <?php echo $i < 2 ? '*' : ''; ?>" <?php echo $i < 2 ? 'required' : ''; ?> style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                    </div>
                    <div style="flex: 1;">
                        <input type="text" name="hi_opt_<?php echo $i; ?>" placeholder="Option <?php echo $i+1; ?> (HI)" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                    </div>
                </div>
                <?php endfor; ?>

                <button type="submit" style="padding: 12px 24px; background: #28a745; font-weight: bold; font-size: 16px; color: white; border: none; border-radius: 4px; cursor: pointer; margin-top: 15px;">Save Question to Quiz</button>
            </form>
        </div>

        <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
            <h4>Questions Added to this Quiz</h4>
            <div style="max-height: 400px; overflow-y: auto;">
                <?php if(!empty($data['questions'])): ?>
                    <?php foreach($data['questions'] as $idx => $q): ?>
                        <div style="border-bottom: 1px solid #eee; padding: 15px 0;">
                            <strong>Q<?php echo $idx+1; ?>.</strong> <?php echo htmlspecialchars($q['default_text']); ?>
                            <span style="font-size: 12px; color: #666; margin-left: 10px;">(Marks: <?php echo $q['marks']; ?> | Diff: <?php echo ucfirst($q['difficulty']); ?>)</span>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No questions added yet.</p>
                <?php endif; ?>
            </div>
        </div>

    </div>
</div>

<?php require_once '../views/layouts/footer.php'; ?>
