<?php
return [
    'login_title' => 'Login to your account',
    'register_title' => 'Create a new account',
    'email' => 'Email Address',
    'password' => 'Password',
    'name' => 'Full Name',
    'login_btn' => 'Login',
    'register_btn' => 'Sign Up',
    'no_account' => 'Don\'t have an account?',
    'have_account' => 'Already have an account?',
    'invalid_credentials' => 'Invalid email or password.',
    'email_taken' => 'Email is already taken.',
    'registration_success' => 'Registration successful! Please login.',
    'logout_success' => 'You have successfully logged out.',
    'welcome' => 'Welcome back',
];
