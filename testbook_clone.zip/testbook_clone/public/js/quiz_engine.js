/**
 * Testbook-style State Engine
 */

let questions = [];
let currentIndex = 0;
let timerSeconds = 0;
let timerInterval = null;
let currentQuestionTimeSpent = 0;

document.addEventListener('DOMContentLoaded', () => {
    timerSeconds = window.QUIZ_CONFIG.timeRemainingSeconds;
    startTimer();
    fetchQuestions();

    document.getElementById('btnSaveNext').addEventListener('click', () => saveAndNext('answered'));
    document.getElementById('btnMarkReview').addEventListener('click', () => {
        let hasSelection = document.querySelector('input[name="option_radio"]:checked') !== null;
        saveAndNext(hasSelection ? 'answered_marked_for_review' : 'marked_for_review');
    });
    document.getElementById('btnClearResponse').addEventListener('click', clearResponse);
    document.getElementById('btnSubmitTest').addEventListener('click', submitTest);
});

function startTimer() {
    updateTimerDisplay();
    timerInterval = setInterval(() => {
        timerSeconds--;
        currentQuestionTimeSpent++;
        updateTimerDisplay();

        if (timerSeconds <= 0) {
            clearInterval(timerInterval);
            alert("Time's up! Your test will auto-submit.");
            submitTest();
        }

        // Sync local timer with server every 1 min
        if (timerSeconds % 60 === 0) {
            syncPing();
        }
    }, 1000);
}

function updateTimerDisplay() {
    let h = Math.floor(timerSeconds / 3600);
    let m = Math.floor((timerSeconds % 3600) / 60);
    let s = timerSeconds % 60;
    document.getElementById('timerDisplay').innerText = 
        `Time Left: ${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
}

async function fetchQuestions() {
    try {
        let res = await fetch(`${window.QUIZ_CONFIG.apiUrl}/fetch_questions?quiz_id=${window.QUIZ_CONFIG.quizId}&lang_id=${window.QUIZ_CONFIG.langId}`);
        let data = await res.json();
        
        if (data.status === 'success') {
            questions = data.questions;
            renderPalette();
            loadQuestion(0);
        } else {
            alert('Failed to load questions.');
        }
    } catch (e) {
        console.error("Fetch Error:", e);
    }
}

function loadQuestion(index) {
    if (index < 0 || index >= questions.length) return;
    
    // Check if moving away from an un-answered, un-visited setup
    if (questions[currentIndex].status === 'not_visited') {
        questions[currentIndex].status = 'not_answered';
        // Need to hit API to save not_answered state silently
        postAnswerState(currentIndex);
    }

    currentIndex = index;
    currentQuestionTimeSpent = 0; // reset local question timer
    let q = questions[currentIndex];

    document.getElementById('questionNumber').innerText = `Question ${currentIndex + 1}`;
    document.getElementById('questionText').innerHTML = q.question_text || 'Text unavailable';
    
    let optionsHtml = '';
    q.options.forEach(opt => {
        let checked = (q.selected_option_id == opt.id) ? 'checked' : '';
        optionsHtml += `
            <label class="option-item">
                <input type="radio" name="option_radio" value="${opt.id}" ${checked}>
                <span>${opt.text}</span>
            </label>
        `;
    });
    document.getElementById('optionsList').innerHTML = optionsHtml;

    updatePaletteSelection();
}

function clearResponse() {
    let radios = document.getElementsByName('option_radio');
    for (let r of radios) r.checked = false;
    
    questions[currentIndex].selected_option_id = null;
    questions[currentIndex].status = 'not_answered';
    postAnswerState(currentIndex);
    
    renderPalette(); // Update grid color instantly
}

async function saveAndNext(status) {
    let selectedId = null;
    let radio = document.querySelector('input[name="option_radio"]:checked');
    if (radio) {
        selectedId = radio.value;
    } else if (status === 'answered') {
        status = 'not_answered'; // Override if clicked Save&Next without choosing
    }

    questions[currentIndex].selected_option_id = selectedId;
    questions[currentIndex].status = status;

    await postAnswerState(currentIndex);
    renderPalette();

    if (currentIndex < questions.length - 1) {
        loadQuestion(currentIndex + 1);
    }
}

async function postAnswerState(qIndex) {
    let q = questions[qIndex];
    let payload = {
        question_id: q.id,
        selected_option_id: q.selected_option_id,
        status: q.status,
        time_spent_seconds: currentQuestionTimeSpent,
        time_remaining_seconds: timerSeconds // piggyback timer sync
    };

    try {
        await fetch(`${window.QUIZ_CONFIG.apiUrl}/save_answer`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
    } catch (e) { console.error("Save Error", e); }
}

async function syncPing() {
    // Just a tiny ping so server knows session is active
    try {
        await fetch(`${window.QUIZ_CONFIG.apiUrl}/save_answer`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                question_id: questions[currentIndex].id,
                status: questions[currentIndex].status, // keeps identical status, just updates timer
                time_spent_seconds: 0,
                time_remaining_seconds: timerSeconds
            })
        });
    } catch (e) {}
}

function renderPalette() {
    let gridHtml = '';
    let counts = { answered: 0, not_answered: 0, not_visited: 0, review: 0, ans_review: 0 };

    questions.forEach((q, idx) => {
        let cssClass = 'q-not-visited';
        if (q.status === 'answered') { cssClass = 'q-answered'; counts.answered++; }
        else if (q.status === 'not_answered') { cssClass = 'q-not-answered'; counts.not_answered++; }
        else if (q.status === 'marked_for_review') { cssClass = 'q-review'; counts.review++; }
        else if (q.status === 'answered_marked_for_review') { cssClass = 'q-answered-review'; counts.ans_review++; }
        else { counts.not_visited++; }

        gridHtml += `<button class="q-btn ${cssClass}" onclick="loadQuestion(${idx})" id="gridBtn${idx}">${idx + 1}</button>`;
    });

    document.getElementById('questionGrid').innerHTML = gridHtml;

    document.getElementById('countAnswered').innerText = counts.answered;
    document.getElementById('countNotAnswered').innerText = counts.not_answered;
    document.getElementById('countNotVisited').innerText = counts.not_visited;
    document.getElementById('countReview').innerText = counts.review;
    document.getElementById('countAnsReview').innerText = counts.ans_review;

    updatePaletteSelection();
}

function updatePaletteSelection() {
    document.querySelectorAll('.q-btn').forEach(b => b.style.boxShadow = 'none');
    let currentBtn = document.getElementById(`gridBtn${currentIndex}`);
    if(currentBtn) currentBtn.style.boxShadow = '0 0 0 3px #2196F3';
}

async function submitTest() {
    if(timerSeconds > 0 && !confirm("Are you sure you want to submit the test?")) return;

    // Submit remaining unsaved states
    await postAnswerState(currentIndex);

    try {
        let res = await fetch(`${window.QUIZ_CONFIG.apiUrl}/submit_test`, { method: 'POST' });
        let data = await res.json();
        if(data.status === 'success') {
            window.location.href = window.QUIZ_CONFIG.baseUrl + '/dashboard';
        }
    } catch (e) {
        alert("Submission failed. Retrying...");
    }
}
