/**
 * Generic Fetch Wrapper handling CSRF security tokens and dynamic loader states automatically.
 * 
 * @param {string} url - Absolute endpoint
 * @param {object} payload - Body params mapping to JSON 
 * @param {boolean} showLoader - Toggle UI blocking explicitly
 */
async function apiFetch(url, payload = null, showLoader = true) {
    if (showLoader) document.getElementById('global-loader').classList.remove('hidden');

    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    let options = {
        method: payload ? 'POST' : 'GET',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': csrfToken
        }
    };

    if (payload) {
        options.body = JSON.stringify(payload);
    }

    try {
        const response = await fetch(url, options);
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status}`);
        }
        return await response.json();
    } catch (e) {
        console.error("apiFetch Error:", e);
        return { status: 'error', message: 'Network operation failed' };
    } finally {
        if (showLoader) document.getElementById('global-loader').classList.add('hidden');
    }
}
